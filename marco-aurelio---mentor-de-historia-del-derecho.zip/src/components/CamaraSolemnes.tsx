import React, { useState } from "react";
import { Award, Flame, Send, RefreshCw, Star, Sparkles, BookOpen, AlertTriangle, CheckCircle2 } from "lucide-react";
import { CEDULARIO_USS } from "../data";
import { SolemnQuestion, WrittenEvaluation } from "../types";

interface CamaraSolemnesProps {
  mentorName: string;
}

export default function CamaraSolemnes({ mentorName }: CamaraSolemnesProps) {
  const [selectedCategory, setSelectedCategory] = useState(CEDULARIO_USS[0].category);
  const [questions, setQuestions] = useState<SolemnQuestion[]>(CEDULARIO_USS[0].questions);
  const [activeQuestion, setActiveQuestion] = useState<SolemnQuestion>(CEDULARIO_USS[0].questions[0]);
  const [studentAnswer, setStudentAnswer] = useState("");
  const [rubricConstraints, setRubricConstraints] = useState("");
  const [loading, setLoading] = useState(false);
  const [aiGenerating, setAiGenerating] = useState(false);
  const [evaluation, setEvaluation] = useState<WrittenEvaluation | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleCategoryChange = (catName: string) => {
    setSelectedCategory(catName);
    const catObj = CEDULARIO_USS.find(c => c.category === catName);
    if (catObj) {
      setQuestions(catObj.questions);
      setActiveQuestion(catObj.questions[0]);
    }
    setEvaluation(null);
    setErrorMsg(null);
  };

  const handleGenerateAIQuestions = async () => {
    setAiGenerating(true);
    setErrorMsg(null);
    try {
      const response = await fetch(`/api/mentor/generate-solemn-questions?category=${encodeURIComponent(selectedCategory)}&mentorName=${encodeURIComponent(mentorName)}`);
      if (!response.ok) {
        throw new Error(`Error al generar solemnes en el servidor.`);
      }
      const data = await response.json();
      if (data.questions && data.questions.length > 0) {
        setQuestions(data.questions);
        setActiveQuestion(data.questions[0]);
      }
    } catch (err: any) {
      setErrorMsg("Ocurrió un error con el archivo inteligente de la IA. Por favor, usa el Cedulario USS por defecto.");
    } finally {
      setAiGenerating(false);
    }
  };

  const handleEvaluateSolemne = async () => {
    if (!studentAnswer.trim()) {
      setErrorMsg("Para poder corregir, es preceptivo redactar una respuesta jurídicamente sólida.");
      return;
    }

    setLoading(true);
    setErrorMsg(null);
    setEvaluation(null);

    try {
      const response = await fetch("/api/mentor/evaluate-written", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: activeQuestion.text,
          studentAnswer,
          rubricConstraints,
          mentorName
        })
      });

      if (!response.ok) {
        throw new Error(`Fallo del corrector de Solemnes USS (código ${response.status})`);
      }

      const data = await response.json();
      setEvaluation(data);
    } catch (err: any) {
      setErrorMsg(err.message || "No pudimos conectar con el corrector de Aula USS.");
    } finally {
      setLoading(false);
    }
  };

  const scoreColor = (score: number) => {
    if (score >= 6.0) return "text-emerald-700 bg-emerald-50 border-emerald-300";
    if (score >= 4.0) return "text-amber-700 bg-amber-50 border-amber-300";
    return "text-red-700 bg-red-50 border-red-300";
  };

  return (
    <div className="space-y-6" id="camara-solemnes-panel">
      {/* Overview Block */}
      <div className="bg-[#211510] border border-[#CCA352]/20 rounded-xl p-5 shadow-lg flex items-center gap-4 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-3 opacity-5 pointer-events-none">
          <Flame className="w-24 h-24 text-[#CCA352]" />
        </div>
        <div className="space-y-1">
          <h2 className="text-xl font-serif font-semibold text-white flex items-center gap-2">
            <Flame className="w-5 h-5 text-[#CCA352]" />
            🕯 Cámara de Solemnes: Corrector de Ensayos Escritos
          </h2>
          <p className="text-xs text-slate-350 leading-relaxed max-w-2xl">
            Someterse a evaluación continua es la clave del éxito. Selecciona un ítem de nuestro Cedulario USS 2026, redacta tu respuesta y {mentorName} te brindará una corrección analítica bajo la estricta rúbrica de la cátedra de Álvaro Iriarte.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Section: Select category and question */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-[#11151D] border border-slate-800 rounded-xl p-4 space-y-4 shadow-xl">
            {/* Category Selector */}
            <div className="space-y-1.5 border-b border-slate-850 pb-3">
              <label className="text-[10px] font-mono uppercase tracking-wider text-slate-500 block">Eje Temático del Cedulario:</label>
              <select
                value={selectedCategory}
                onChange={(e) => handleCategoryChange(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-md p-2 text-xs font-serif text-white focus:outline-none focus:ring-1 focus:ring-[#CCA352]"
                id="solemn-category-selector"
              >
                {CEDULARIO_USS.map((item, idx) => (
                  <option key={idx} value={item.category}>{item.category}</option>
                ))}
              </select>
            </div>

            {/* Questions from category */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center mb-1">
                <label className="text-[10px] font-mono uppercase tracking-wider text-slate-500">Preguntas Seleccionadas:</label>
                <button
                  onClick={handleGenerateAIQuestions}
                  disabled={aiGenerating}
                  className="flex items-center gap-1 text-[9px] font-bold font-mono text-[#CCA352] hover:underline"
                  id="ai-generate-questions-btn"
                >
                  <Sparkles className="w-2.5 h-2.5" />
                  Generar con IA ⚡️
                </button>
              </div>

              {aiGenerating ? (
                <div className="py-8 text-center text-xs font-mono text-slate-400">
                  <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-[#CCA352]" />
                  Compilando preguntas...
                </div>
              ) : (
                <div className="space-y-2 max-h-[250px] overflow-y-auto pr-1" id="solemns-questions-list">
                  {questions.map((q) => (
                    <button
                      key={q.id}
                      onClick={() => {
                        setActiveQuestion(q);
                        setEvaluation(null);
                        setErrorMsg(null);
                      }}
                      className={`w-full text-left p-3 rounded-lg border text-xs leading-snug font-serif transition-colors ${
                        activeQuestion.id === q.id
                          ? "bg-[#CCA352]/10 border-[#CCA352] text-white font-bold"
                          : "bg-slate-950 border-slate-850 text-slate-400 hover:border-slate-800 hover:text-slate-200"
                      }`}
                      id={`solemn-q-btn-${q.id}`}
                    >
                      {q.id}. {q.title}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Mentor suggestion for selected question */}
            <div className="bg-slate-950/60 rounded-lg p-3.5 border border-slate-800">
              <span className="text-[9px] font-mono uppercase tracking-wider text-[#BCA374] block mb-1">🔍 Pauta de Enfoque Socrático:</span>
              <p className="text-[11px] font-serif italic text-slate-400 leading-normal">
                &ldquo;{activeQuestion.mentorTip}&rdquo;
              </p>
            </div>
          </div>
        </div>

        {/* Center/Right Section: Write answer and see correcting board */}
        <div className="lg:col-span-8 space-y-5">
          {/* Question Text Prompt */}
          <div className="bg-[#11151D] border border-[#CCA352]/10 rounded-xl p-5 shadow-xl space-y-4">
            <div className="flex justify-between items-center text-[10px] font-mono border-b border-slate-850 pb-2 mb-1">
              <span className="text-[#CCA352] font-semibold flex items-center gap-1">
                🏷 CUESTIONARIO USS {activeQuestion.id}
              </span>
              <span className="text-slate-450 uppercase">
                {selectedCategory}
              </span>
            </div>

            <div className="space-y-1">
              <h3 className="text-sm font-serif font-bold text-white leading-relaxed">
                {activeQuestion.text}
              </h3>
            </div>

            <div className="space-y-3 pt-1">
              <div>
                <label className="text-[10px] font-mono uppercase tracking-wider text-slate-450 block mb-1">Sugerencia de Rúbrica Adicional (Opcional):</label>
                <input
                  type="text"
                  placeholder="Ej: Exigir citas a Álvaro Iriarte, exigir latín, evaluar excesivamente severo..."
                  value={rubricConstraints}
                  onChange={(e) => setRubricConstraints(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-850 rounded-lg px-3 py-2 text-xs text-white focus:ring-1 focus:ring-[#CCA352] focus:outline-none"
                  id="solemn-rubric-input"
                />
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase tracking-wider text-slate-450 block mb-1.5">Tu Respuesta para Corrección:</label>
                <textarea
                  value={studentAnswer}
                  onChange={(e) => setStudentAnswer(e.target.value)}
                  disabled={loading}
                  placeholder="Escribe de manera prolija tu respuesta doctrinal. Intenta estructurarla de forma deductiva, explicando el marco legal, la teoría de fondo, y evitando la narración descriptiva..."
                  className="bg-slate-950 border border-slate-850 rounded-lg p-4 text-xs font-serif text-white h-44 w-full focus:outline-none focus:ring-2 focus:ring-[#CCA352]/40"
                  id="solemn-answer-textarea"
                />
              </div>
            </div>

            {errorMsg && (
              <div className="bg-red-950/40 border border-red-900 rounded-lg p-3 text-red-200 text-xs">
                ⚠️ Error de Examen: {errorMsg}
              </div>
            )}

            <div className="flex justify-end">
              <button
                onClick={handleEvaluateSolemne}
                disabled={loading}
                className="bg-gradient-to-r from-[#BCA374] to-[#CCA352] text-slate-950 hover:brightness-110 font-bold font-mono text-xs uppercase tracking-widest px-6 py-3 rounded-lg flex items-center gap-2 transition-all disabled:opacity-50 shadow-md shadow-[#CCA352]/5"
                id="evaluate-solemn-btn"
              >
                {loading ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    Corrigiendo bajo Rúbrica USS...
                  </>
                ) : (
                  <>
                    <BookOpen className="w-3.5 h-3.5" />
                    Someter a Corrección
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Loader */}
          {loading && (
            <div className="bg-[#11151D] border border-slate-800 rounded-xl p-8 text-center" id="solemn-loader">
              <RefreshCw className="w-8 h-8 text-[#CCA352] animate-spin mx-auto mb-3" />
              <p className="text-xs font-serif italic text-slate-400">
                &ldquo;Revisando con rigor forense. Analizando asimilación doctrinal, precisión lingüística de conceptos históricos y descartando analogías moralistas o subversivas... Un momento.&rdquo;
              </p>
            </div>
          )}

          {/* Results Display */}
          {evaluation && !loading && (
            <div className="bg-[#FAF8F5] text-slate-900 border border-[#CCA352]/20 rounded-xl p-6 shadow-2xl relative overflow-hidden" id="solemn-evaluation-parchment">
              <div className="flex items-center justify-between border-b pb-3 mb-4 border-slate-300">
                <span className="font-mono text-[9px] uppercase tracking-widest text-[#BCA374] font-bold">
                  Solemne Escrito Corregido • Universidad San Sebastián
                </span>
                <span className="text-xs italic text-slate-500">Formulario USS - Decanato</span>
              </div>

              {/* Score assessment */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center mb-5 bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
                <div className="md:col-span-8 space-y-1">
                  <span className="text-[10px] font-mono text-slate-400 block uppercase">Clasificación de Nota USS:</span>
                  <p className="text-sm font-serif font-extrabold text-slate-800">
                    {evaluation.score >= 4.0 ? "Aprobación Regulada del Sínodo" : "Fracaso Doctrinal por Enmienda Requerida"}
                  </p>
                  <p className="text-[10px] text-slate-550 leading-relaxed font-sans">
                    Basado en un análisis exhaustivo del contenido e histografía jurídica en la escala nacional.
                  </p>
                </div>
                <div className="md:col-span-4 text-center">
                  <div className={`p-3 rounded-lg border text-center font-bold ${scoreColor(evaluation.score)}`}>
                    <span className="text-[9px] font-mono uppercase block text-slate-500">Nota del Apunte:</span>
                    <span className="text-3xl font-serif font-black">{evaluation.score.toFixed(1)}</span>
                  </div>
                </div>
              </div>

              {/* Assessment Lists */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-emerald-50 border border-emerald-100 p-3 rounded-lg text-emerald-950 text-xs">
                  <strong className="block text-[10px] font-mono uppercase text-emerald-800 mb-1">✓ Virtudes de la Exposición:</strong>
                  <ul className="list-disc pl-4 space-y-1 font-serif">
                    {evaluation.strengths.map((str, i) => <li key={i}>{str}</li>)}
                  </ul>
                </div>
                <div className="bg-red-50 border border-red-100 p-3 rounded-lg text-red-950 text-xs">
                  <strong className="block text-[10px] font-mono uppercase text-red-800 mb-1">✗ Debilidades & Imprecisiones:</strong>
                  <ul className="list-disc pl-4 space-y-1 font-serif">
                    {evaluation.weaknesses.map((wk, i) => <li key={i}>{wk}</li>)}
                  </ul>
                </div>
              </div>

              {/* Doctrinal Correction */}
              <div className="space-y-1.5 pt-4">
                <h4 className="text-[10px] uppercase font-mono tracking-wider text-[#BCA374] font-extrabold flex items-center gap-1">
                  🗣 Enmienda de Cátedra:
                </h4>
                <p className="text-xs text-slate-700 leading-relaxed font-serif text-justify bg-slate-100/60 p-3.5 rounded border border-slate-200">
                  {evaluation.doctrineFix}
                </p>
              </div>

              {/* Rewritten Perfect Answer */}
              <div className="space-y-1.5 pt-3">
                <h4 className="text-[10px] uppercase font-mono tracking-wider text-emerald-850 font-extrabold flex items-center gap-1">
                  🌟 Propuesta Modelo (Calificación 7.0):
                </h4>
                <div className="bg-slate-900 text-slate-100 p-4 rounded-lg font-serif text-xs italic leading-relaxed text-justify relative relative shadow-inner">
                  <p>&ldquo;{evaluation.rewrittenModel}&rdquo;</p>
                </div>
              </div>

              {/* Corrective Socratic Question */}
              <div className="my-5 p-4 bg-amber-50 border-l-4 border-[#CCA352] rounded-r-lg text-slate-800 text-xs font-serif leading-relaxed shadow-sm">
                <p className="font-bold font-mono tracking-widest text-[9px] uppercase text-amber-800 mb-1 flex items-center gap-1">
                  🕵️‍♂️ CORRECCIÓN SOCRÁTICA DE RETORNO:
                </p>
                {evaluation.socrativeCorrection}
              </div>

              <div className="mt-6 pt-4 border-t border-slate-200 text-[10px] text-slate-500 font-mono text-center">
                &ldquo;Intellige Historiam, Comprehende Ius • Universidad San Sebastián&rdquo;
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
