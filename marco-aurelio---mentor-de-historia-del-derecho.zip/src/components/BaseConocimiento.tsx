import React, { useState } from "react";
import { BookOpen, Search, ArrowRight, RefreshCw, Sparkles, Book, Layers, HelpCircle, CheckCircle, Copy, Check } from "lucide-react";
import { APUNTES_CHAPTERS, SOLEMN_RECUPERATIVA_QUESTIONS, ChapterData, QuestionData } from "../dataNotes";

interface BaseConocimientoProps {
  mentorName: string;
}

export default function BaseConocimiento({ mentorName }: BaseConocimientoProps) {
  const [activeTab, setActiveTab] = useState<"cedulario" | "apuntes">("cedulario");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTopicFilter, setSelectedTopicFilter] = useState("Todos");
  
  // Selection States
  const [selectedQuestion, setSelectedQuestion] = useState<QuestionData | null>(SOLEMN_RECUPERATIVA_QUESTIONS[0]);
  const [selectedChapter, setSelectedChapter] = useState<ChapterData | null>(APUNTES_CHAPTERS[0]);
  
  // Interactive Mentor Query State
  const [mentorResponse, setMentorResponse] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [copiedQuestion, setCopiedQuestion] = useState(false);
  const [copiedModel, setCopiedModel] = useState(false);

  // Filters categories of the Cedulario
  const topicsList = ["Todos", ...Array.from(new Set(SOLEMN_RECUPERATIVA_QUESTIONS.map(q => q.topic)))];

  // Filtering Logic for Questions
  const filteredQuestions = SOLEMN_RECUPERATIVA_QUESTIONS.filter(q => {
    const matchesSearch = q.question.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          q.id.toString().includes(searchQuery);
    const matchesTopic = selectedTopicFilter === "Todos" || q.topic === selectedTopicFilter;
    return matchesSearch && matchesTopic;
  });

  const handleCopyQuestion = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedQuestion(true);
    setTimeout(() => setCopiedQuestion(false), 2000);
  };

  const handleCopyModel = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedModel(true);
    setTimeout(() => setCopiedModel(false), 2000);
  };

  const askMentorAboutQuestion = async (question: QuestionData) => {
    setLoading(true);
    setMentorResponse(null);
    try {
      const customPrompt = `Como ${mentorName}, bríndame una explicación dogmática, socrática y de excelencia para la siguiente pregunta real del Cedulario de Solemne de Historia del Derecho USS:
      
      PREGUNTA: "${question.id}. ${question.question}"
      TEMA ASOCIADO: "${question.topic}"
      SUGERENCIA DE CÁTEDRA: "${question.summaryTip}"
      
      Estructura tu tutoría académica así:
      1. 🧭 REVELACIÓN DOCTRINAL (Ratio Iuris): Cuál es el núcleo explicativo estricto según las clases del Prof. Álvaro Iriarte Baron.
      2. 📜 VÍNCULO HISTÓRICO: Qué fuentes históricas o textos normativos sustenta la respuesta (ej. Leyes de Partida, Constitución de 1833, etc.).
      3. 🏛️ MODELO DE RESPUESTA 7.0: Redacta una respuesta modelo impecable, precisa y elegante en un solo párrafo condensado de alta exigencia forense.
      4. 🍎 PREGUNTA SOCRÁTICA: Plantea una pregunta crítica para desafiarme y obligarme a razonar críticamente sobre esta institución jurídica.`;

      const response = await fetch("/api/mentor/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: "custom-query",
          customPrompt,
          mentorName
        })
      });

      if (!response.ok) {
        throw new Error("No se pudo obtener la explicación del Mentor Académico.");
      }

      const data = await response.json();
      setMentorResponse(data.text);
    } catch (err: any) {
      console.error(err);
      setMentorResponse(`⚠️ Error al invocar la cátedra de ${mentorName}: ${err.message || "Inténtalo de nuevo."}`);
    } finally {
      setLoading(false);
    }
  };

  const askMentorAboutChapter = async (chapter: ChapterData) => {
    setLoading(true);
    setMentorResponse(null);
    try {
      const customPrompt = `Como ${mentorName}, doctor e instructor USS, haz una clase interactiva del siguiente capítulo del programa oficial de Historia del Derecho de Álvaro Iriarte:
      
      CAPÍTULO: "Capítulo ${chapter.id}: ${chapter.title}"
      SÍNTESIS DOCTRINAL: "${chapter.summary}"
      CONCEPTOS CLAVE: ${chapter.keyConcepts.join(", ")}
      
      Estructura tu tutoría doctrinal así:
      1. ⭐ EXÉGESIS CONSTITUCIONAL: Brinda una clase de 2 a 3 párrafos de alta densidad y claridad sobre los misterios jurídicos de este capítulo. Cita teóricos clave (ej. D'Ors, Burke, Portales, Guzmán, etc.).
      2. 📖 EXTREMO DE RÚBRICA USS: Explica la diferencia entre responder esto puramente como 'historia narrativa lineal' versus responder como 'doctrina jurídica/historia constitucional'.
      3. 💡 DESAFÍO DIRECTO: Plantea un caso hipotético en la práctica o una pregunta socrática de nivel examen regular de grado sobre este tema.`;

      const response = await fetch("/api/mentor/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: "custom-query",
          customPrompt,
          mentorName
        })
      });

      if (!response.ok) {
        throw new Error("No se pudo obtener el extracto explicativo.");
      }

      const data = await response.json();
      setMentorResponse(data.text);
    } catch (err: any) {
      console.error(err);
      setMentorResponse(`⚠️ Error al invocar la cátedra de ${mentorName}: ${err.message || "Inténtalo de nuevo."}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6" id="base-conocimiento-screen">
      {/* Overview Card */}
      <div className="bg-[#0B1520] border border-[#CCA352]/20 rounded-xl p-5 shadow-lg relative overflow-hidden">
        <div className="absolute right-0 top-0 text-[#CCA352]/5 text-9xl font-serif pointer-events-none select-none">
          USS
        </div>
        <div className="flex items-center gap-3">
          <Book className="w-6 h-6 text-[#CCA352] animate-pulse" />
          <div>
            <h2 className="text-xl font-serif font-semibold text-white">
              Cuerpo Doctrinal & Cedulario de Historia del Derecho
            </h2>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              BASE DE CONOCIMIENTO OFICIAL • CURSO DEL PROF. ÁLVARO IRIARTE BARON
            </p>
          </div>
        </div>
        <p className="text-xs text-slate-300 mt-2 leading-relaxed max-w-4xl">
          Explora la totalidad de los apuntes doctrinales sistematizados de la cátedra (<strong>118 páginas</strong> de apuntes constitucionales e históricos) y prepara activamente el <strong>Cedulario del Solemne Recuperativa de 45 preguntas</strong> redactado formalmente por la Universidad San Sebastián. Haz clic en cualquier pregunta para estudiar sus pautas y recibir su exégesis socrática instantánea de parte de {mentorName}.
        </p>
      </div>

      {/* Screen Navigation Tabs */}
      <div className="flex border-b border-slate-800" id="base-conocimiento-tabs">
        <button
          onClick={() => { setActiveTab("cedulario"); setMentorResponse(null); }}
          className={`flex-1 py-3 text-xs font-mono uppercase tracking-wider border-b-2 text-center transition-all ${
            activeTab === "cedulario" ? "border-[#CCA352] text-white bg-slate-900/40" : "border-transparent text-slate-400 hover:text-slate-200"
          }`}
          id="btn-tab-cedulario-recuperativo"
        >
          📜 A. Preguntas Recuperativas Solemne (45 Ítems)
        </button>
        <button
          onClick={() => { setActiveTab("apuntes"); setMentorResponse(null); }}
          className={`flex-1 py-3 text-xs font-mono uppercase tracking-wider border-b-2 text-center transition-all ${
            activeTab === "apuntes" ? "border-[#CCA352] text-white bg-slate-900/40" : "border-transparent text-slate-400 hover:text-slate-200"
          }`}
          id="btn-tab-apuntes-catedra"
        >
          📖 B. Apuntes del Profesor Álvaro Iriarte (9 Capítulos)
        </button>
      </div>

      {/* RENDER ACTIVE TAB: CEDULARIO DE 45 PREGUNTAS */}
      {activeTab === "cedulario" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="cedulario-grid-layout">
          
          {/* SEARCH & QUESTIONS LIST PANEL (LEFT COLUMN) */}
          <div className="lg:col-span-5 space-y-4 flex flex-col h-[600px]">
            {/* Search and filter header */}
            <div className="bg-[#11151D] border border-slate-800 rounded-xl p-4 space-y-3">
              <div className="relative">
                <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                <input
                  type="text"
                  placeholder="Buscar de entre las 45 preguntas..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-xs text-white rounded-lg pl-9 pr-3 py-2 focus:ring-1 focus:ring-[#CCA352] focus:outline-none"
                  id="search-questions-input"
                />
              </div>

              {/* Topic Filters list */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {topicsList.map((topic, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedTopicFilter(topic)}
                    className={`text-[9px] font-mono uppercase tracking-wider px-2 py-1 rounded transition-all border ${
                      selectedTopicFilter === topic
                        ? "bg-[#CCA352]/20 border-[#CCA352] text-[#CCA352] font-semibold"
                        : "bg-slate-900 border-transparent text-slate-400 hover:text-slate-200"
                    }`}
                    id={`topic-filter-btn-${index}`}
                  >
                    {topic}
                  </button>
                ))}
              </div>
            </div>

            {/* Questions scrolling container */}
            <div className="flex-1 overflow-y-auto pr-1 space-y-2 border border-slate-850/50 rounded-xl p-2 bg-slate-950/20" id="scrollable-questions-list">
              {filteredQuestions.length === 0 ? (
                <div className="text-center py-12 text-slate-500 text-xs italic">
                  No se encontraron preguntas bajo los criterios seleccionados.
                </div>
              ) : (
                filteredQuestions.map((q) => (
                  <button
                    key={q.id}
                    onClick={() => {
                      setSelectedQuestion(q);
                      setMentorResponse(null);
                    }}
                    className={`w-full text-justify p-3 rounded-lg border transition-all flex gap-3 ${
                      selectedQuestion?.id === q.id
                        ? "bg-[#CCA352]/5 border-[#CCA352] text-white shadow"
                        : "bg-slate-900/30 border-slate-850/40 text-slate-300 hover:bg-slate-900/60 hover:text-slate-100"
                    }`}
                    id={`question-card-item-${q.id}`}
                  >
                    <span className="font-mono text-xs font-bold text-[#CCA352] h-6 w-6 rounded-full bg-slate-950 flex items-center justify-center shrink-0 border border-slate-850">
                      {q.id}
                    </span>
                    <div className="space-y-1">
                      <p className="text-xs font-serif leading-tight">{q.question}</p>
                      <span className="inline-block text-[8px] font-mono border border-slate-800 text-slate-400 px-1.5 rounded uppercase font-semibold">
                        {q.topic}
                      </span>
                    </div>
                  </button>
                ))
              )}
            </div>
            
            <div className="text-[10px] text-slate-500 font-mono text-center">
              Mostrando {filteredQuestions.length} de {SOLEMN_RECUPERATIVA_QUESTIONS.length} preguntas de Solemne Recuperativa
            </div>
          </div>

          {/* ACTIVE QUESTION EXÉGESIS AND CHAT CORES (RIGHT COLUMN) */}
          <div className="lg:col-span-7 space-y-4 flex flex-col h-[600px] overflow-y-auto">
            {selectedQuestion ? (
              <div className="bg-[#11151D] border border-slate-800 rounded-xl p-5 space-y-4 relative flex-1 flex flex-col justify-between" id="active-question-details">
                <div className="space-y-4">
                  {/* Card head metadata */}
                  <div className="flex justify-between items-start gap-4 pb-2 border-b border-slate-800">
                    <div>
                      <span className="text-[9px] font-mono text-[#CCA352] uppercase tracking-widest block font-bold">
                        PREGUNTA {selectedQuestion.id} DE EXAMEN RECUPERATIVO
                      </span>
                      <h3 className="text-base font-serif font-bold text-white mt-1 leading-snug">
                        {selectedQuestion.question}
                      </h3>
                    </div>
                    <button
                      onClick={() => handleCopyQuestion(`${selectedQuestion.id}. ${selectedQuestion.question}`)}
                      className="border border-slate-800 text-slate-400 hover:text-white p-1.5 rounded-lg transition-colors hover:bg-slate-950"
                      title="Copiar pregunta"
                      id="copy-question-btn"
                    >
                      {copiedQuestion ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>

                  {/* Doctrinal syllabus Tip / Hint */}
                  <div className="bg-[#0B121B] border border-slate-800 px-4 py-3.5 rounded-lg space-y-1.5">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-[#BCA374] block font-bold">
                      💡 Claves Doctrinales del Prof. Álvaro Iriarte Baron:
                    </span>
                    <p className="text-xs text-slate-300 font-serif leading-relaxed text-justify">
                      {selectedQuestion.summaryTip}
                    </p>
                  </div>

                  {/* Associated Chapter Reference */}
                  <div className="text-xs text-slate-400 font-mono flex items-center gap-2">
                    <Layers className="w-4 h-4 text-[#CCA352]" />
                    <span>Unidad de estudio: </span>
                    <span className="text-white underline font-semibold">
                      {APUNTES_CHAPTERS.find(c => c.associatedQuestions.includes(selectedQuestion.id))?.title || "Teoría General / Todo el Ramo"}
                    </span>
                  </div>
                </div>

                {/* Ask Mentor Button */}
                <div className="pt-4 border-t border-slate-800 flex justify-end">
                  <button
                    onClick={() => askMentorAboutQuestion(selectedQuestion)}
                    disabled={loading}
                    className="w-full sm:w-auto bg-gradient-to-r from-[#CCA352] to-[#BCA374] text-slate-950 hover:brightness-105 font-mono text-xs uppercase tracking-wider font-bold px-5 py-3 rounded-xl flex items-center justify-center gap-2 transition-all shadow-md disabled:opacity-50"
                    id="trigger-mentor-explanation-btn"
                  >
                    {loading ? (
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Sparkles className="w-3.5 h-3.5" />
                    )}
                    EXPLICACIÓN COMPLETA DE {mentorName.toUpperCase()}
                  </button>
                </div>
              </div>
            ) : (
              <div className="bg-[#11151D] border border-slate-800 rounded-xl p-12 text-center h-full flex flex-col items-center justify-center text-slate-500 text-xs italic">
                <HelpCircle className="w-8 h-8 text-slate-700 mb-2 animate-bounce" />
                Selecciona una de las 45 preguntas en el panel izquierdo para desentrañar sus respuestas doctrinales oficiales.
              </div>
            )}
          </div>
        </div>
      )}

      {/* RENDER ACTIVE TAB: SÍNTESIS DE APUNTES (118 PÁGINAS, 9 CAPÍTULOS) */}
      {activeTab === "apuntes" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="apuntes-grid-layout">
          
          {/* CHAPTERS INDEX PANEL (LEFT COLUMN) */}
          <div className="lg:col-span-5 space-y-2 max-h-[600px] overflow-y-auto pr-1">
            <span className="text-[10px] font-mono uppercase tracking-widest text-slate-500 block mb-2 px-1">
              Programa de Estudio Doctrinal USS:
            </span>
            {APUNTES_CHAPTERS.map((chapter) => (
              <button
                key={chapter.id}
                onClick={() => {
                  setSelectedChapter(chapter);
                  setMentorResponse(null);
                }}
                className={`w-full text-justify p-3.5 rounded-xl border transition-all flex flex-col gap-1.5 ${
                  selectedChapter?.id === chapter.id
                    ? "bg-[#CCA352]/5 border-[#CCA352] text-white shadow"
                    : "bg-slate-900/30 border-slate-850/40 text-slate-300 hover:bg-slate-900/60 hover:text-slate-100"
                }`}
                id={`chapter-card-item-${chapter.id}`}
              >
                <div className="flex items-center justify-between gap-2 w-full">
                  <span className="text-[10px] font-mono text-[#CCA352] font-bold">
                    CAPÍTULO {chapter.id}
                  </span>
                  <span className="text-[9px] font-mono text-slate-500 italic bg-slate-900 px-2 py-0.5 rounded border border-slate-850">
                    {chapter.pages}
                  </span>
                </div>
                <h4 className="text-xs font-serif font-bold text-slate-200">
                  {chapter.title}
                </h4>
              </button>
            ))}
          </div>

          {/* ACTIVE CHAPTER DATA & EXPERT CLASS (RIGHT COLUMN) */}
          <div className="lg:col-span-7 space-y-4 flex flex-col h-[600px] overflow-y-auto">
            {selectedChapter ? (
              <div className="bg-[#11151D] border border-slate-800 rounded-xl p-5 space-y-4 relative flex-1 flex flex-col justify-between" id="active-chapter-details">
                <div className="space-y-4">
                  {/* Card head metadata */}
                  <div className="border-b border-slate-800 pb-3">
                    <div className="flex items-center justify-between gap-4">
                      <span className="text-[9px] font-mono text-[#CCA352] uppercase tracking-widest font-bold">
                        GUÍA DE REPASO • MANUAL DE CÁTEDRA USS
                      </span>
                      <span className="text-[10px] font-mono text-slate-500 bg-slate-950 px-2 py-0.5 rounded border border-slate-850 font-semibold">
                        Syllabus: {selectedChapter.pages}
                      </span>
                    </div>
                    <h3 className="text-base font-serif font-bold text-white mt-1 leading-tight">
                      Capítulo {selectedChapter.id}: {selectedChapter.title}
                    </h3>
                  </div>

                  {/* High Quality Chapter Summary */}
                  <div className="space-y-2">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500 block font-bold">
                      Resumen Analítico Estructurado:
                    </span>
                    <p className="text-xs text-slate-200 font-serif leading-relaxed text-justify bg-slate-950/40 p-3 rounded-lg border border-slate-850/30">
                      {selectedChapter.summary}
                    </p>
                  </div>

                  {/* Key Concepts Tags */}
                  <div className="space-y-1.5">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-[#BCA374] block font-bold">
                      Conceptos Clave para Fundamentar:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {selectedChapter.keyConcepts.map((concept, index) => (
                        <span
                          key={index}
                          className="bg-slate-950 border border-slate-800 text-[10px] font-mono text-slate-300 px-2.5 py-1 rounded"
                        >
                          📌 {concept}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Linked Solemne Questions list */}
                  <div className="space-y-2">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-teal-400 block font-bold">
                      🎯 Preguntas de Solemne Recuperativa vinculadas:
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {selectedChapter.associatedQuestions.map((qId) => {
                        const questionObj = SOLEMN_RECUPERATIVA_QUESTIONS.find(q => q.id === qId);
                        if (!questionObj) return null;
                        return (
                          <div
                            key={qId}
                            className="bg-slate-950 border border-slate-900 hover:border-slate-800 p-2.5 rounded-lg text-left text-[11px] text-slate-300 font-serif flex gap-2 cursor-pointer transition-colors"
                            onClick={() => {
                              setActiveTab("cedulario");
                              setSelectedQuestion(questionObj);
                              setMentorResponse(null);
                            }}
                          >
                            <span className="font-mono text-[9px] font-bold text-[#CCA352] bg-slate-900 h-5 w-5 rounded-full border border-slate-800 flex items-center justify-center shrink-0">
                              {qId}
                            </span>
                            <span className="line-clamp-2 leading-snug">{questionObj.question}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Ask Mentor Button */}
                <div className="pt-4 border-t border-slate-800 flex justify-end">
                  <button
                    onClick={() => askMentorAboutChapter(selectedChapter)}
                    disabled={loading}
                    className="w-full sm:w-auto bg-gradient-to-r from-slate-900 to-slate-850 hover:to-slate-800 border border-slate-700 text-[#CCA352] font-mono text-xs uppercase tracking-wider font-bold px-5 py-3 rounded-xl flex items-center justify-center gap-2 transition-all shadow-md disabled:opacity-50"
                    id="trigger-mentor-chapter-btn"
                  >
                    {loading ? (
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Sparkles className="w-3.5 h-3.5 text-[#CCA352]" />
                    )}
                    ASISTENCIA ACADÉMICA PERSONAL DE ESTE TEMA
                  </button>
                </div>
              </div>
            ) : (
              <div className="bg-[#11151D] border border-slate-800 rounded-xl p-12 text-center h-full flex flex-col items-center justify-center text-slate-500 text-xs italic">
                <HelpCircle className="w-8 h-8 text-slate-700 mb-2 animate-bounce" />
                Selecciona un capítulo de la cátedra para estudiar sus conceptos doctrinales y rendir en los solemnes de la USS.
              </div>
            )}
          </div>
        </div>
      )}

      {/* LOADER BLOCK FOR API CALLS */}
      {loading && (
        <div className="bg-[#11151D] border border-slate-800/40 rounded-xl p-10 text-center animate-pulse" id="mentor-response-loader">
          <RefreshCw className="w-8 h-8 text-[#CCA352] animate-spin mx-auto mb-3" />
          <h4 className="text-xs font-mono font-bold uppercase text-white tracking-widest">Invocando el Núcleo Cognitivo de {mentorName}</h4>
          <p className="text-[11px] font-serif italic text-slate-400 mt-1">
            Analizando exégesis legal y citas doctrinales del curso para brindarte una tutoría dogmática... Por favor aguarda.
          </p>
        </div>
      )}

      {/* DETAILED MENTOR PARCHMENT RESPONSE WINDOW */}
      {mentorResponse && !loading && (
        <div className="bg-[#FAF8F5] text-slate-900 border border-[#CCA352]/30 rounded-xl p-6 shadow-2xl font-serif text-justify transition-all relative" id="doctrinal-mentor-parchment">
          <div className="absolute right-4 top-4">
            <button
              onClick={() => handleCopyModel(mentorResponse)}
              className="border border-slate-200 hover:border-[#CCA352] text-slate-500 hover:text-[#CCA352] p-1.5 rounded-lg transition-colors hover:bg-slate-50"
              title="Copiar texto doctrinal"
              id="copy-model-btn"
            >
              {copiedModel ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>

          <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
            <div>
              <span className="font-mono text-[9px] uppercase tracking-widest text-[#BCA374] font-bold">
                Cátedra Virtual Dr. Álvaro Iriarte Baron USS
              </span>
              <h3 className="text-xs italic text-slate-500 mt-0.5">Tutoría Exclusiva impartida por {mentorName}</h3>
            </div>
            <span className="text-[10px] uppercase font-mono text-slate-400 bg-slate-100 px-2 py-0.5 rounded border border-slate-200 hidden sm:block">
              Dictamen Académico
            </span>
          </div>

          <div className="prose prose-sm max-w-none text-slate-800 space-y-4">
            {mentorResponse.split("\n").map((line, idx) => {
              const trimmed = line.trim();
              if (!trimmed) return <div key={idx} className="h-2" />;

              // Identifies Markdown headers for stylized displays
              if (trimmed.startsWith("###") || trimmed.startsWith("##") || trimmed.startsWith("1.") || trimmed.startsWith("2.") || trimmed.startsWith("3.") || trimmed.startsWith("4.") || trimmed.startsWith("🧭") || trimmed.startsWith("📜") || trimmed.startsWith("🏛️") || trimmed.startsWith("🍎") || trimmed.startsWith("⭐") || trimmed.startsWith("📖") || trimmed.startsWith("💡")) {
                return (
                  <h4 key={idx} className="text-xs font-bold font-mono tracking-wide text-slate-950 mt-5 border-b border-amber-200 pb-1 uppercase flex items-center gap-1.5">
                    {trimmed.replace(/###|##/g, "").trim()}
                  </h4>
                );
              }

              // Simple strong replacement for aesthetics
              const formattedLine = trimmed.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");

              return (
                <p 
                  key={idx} 
                  className="text-xs text-slate-700 leading-relaxed font-serif text-justify"
                  dangerouslySetInnerHTML={{ __html: formattedLine }}
                />
              );
            })}
          </div>

          <div className="mt-8 pt-4 border-t border-slate-200 text-[10px] text-slate-400 font-mono text-center flex flex-col sm:flex-row items-center justify-between gap-2">
            <span>&ldquo;Aprender a discernir jurídicamente, nunca memorizar mecánicamente.&rdquo;</span>
            <span className="text-[#BCA374] font-bold uppercase font-sans">COMISION DE EXAMEN USS 2026</span>
          </div>
        </div>
      )}
    </div>
  );
}
