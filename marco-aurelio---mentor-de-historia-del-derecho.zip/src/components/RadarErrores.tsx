import React, { useState } from "react";
import { AlertOctagon, RefreshCw, Send, CheckCircle2, XCircle, SearchCode } from "lucide-react";
import { CLASSIC_ERRORS } from "../data";
import { RefineryResult } from "../types";

interface RadarErroresProps {
  mentorName: string;
}

export default function RadarErrores({ mentorName }: RadarErroresProps) {
  const [activeErrorId, setActiveErrorId] = useState<string | null>(CLASSIC_ERRORS[0].id);
  const [draftSnippet, setDraftSnippet] = useState("");
  const [selectedErrorType, setSelectedErrorType] = useState(CLASSIC_ERRORS[0].title);
  const [loading, setLoading] = useState(false);
  const [refineryResult, setRefineryResult] = useState<RefineryResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const selectedErrorObj = CLASSIC_ERRORS.find(err => err.id === activeErrorId);

  const handleRefine = async () => {
    if (!draftSnippet.trim()) {
      setErrorMsg("Por favor escribe tu borrador de respuesta legal para refinarlo.");
      return;
    }

    setLoading(true);
    setRefineryResult(null);
    setErrorMsg(null);

    try {
      const response = await fetch("/api/mentor/refinery", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          draftSnippet,
          errorType: selectedErrorType,
          mentorName
        })
      });

      if (!response.ok) {
        throw new Error(`Error en el servidor de refinería (código ${response.status})`);
      }

      const data = await response.json();
      setRefineryResult(data);
    } catch (err: any) {
      setErrorMsg(err.message || "No se pudo refinar tu texto en este momento.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6" id="radar-errores-panel">
      {/* Intro Header */}
      <div className="bg-[#1C1014] border border-red-900/30 rounded-xl p-5 shadow-lg">
        <h2 className="text-xl font-serif font-semibold text-white flex items-center gap-2">
          <AlertOctagon className="text-red-500 w-5 h-5 animate-pulse" />
          🛡 Radar de Errores Doctrinarios y Históricos USS
        </h2>
        <p className="text-xs text-slate-300 mt-1 lines-relaxed">
          Muchos alumnos reprobados culpan a la memoria cuando el verdadero culpable es cometer errores conceptuales elementales. {mentorName} mapea los 4 sesgos graves que la cátedra de Álvaro Iriarte detecta al instante durante los solemnes.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Select error map */}
        <div className="lg:col-span-5 space-y-4">
          <label className="text-[10px] font-mono uppercase tracking-widest text-slate-450 block px-1">Sesgos Doctrinales Críticos (Ronda del Cedulario):</label>
          <div className="space-y-2" id="errors-accordion">
            {CLASSIC_ERRORS.map((item, idx) => (
              <button
                key={item.id}
                onClick={() => {
                  setActiveErrorId(item.id);
                  setSelectedErrorType(item.title);
                }}
                className={`w-full text-left p-3.5 rounded-xl border transition-all ${
                  activeErrorId === item.id
                    ? "bg-red-950/20 border-red-800/60 text-white shadow-md shadow-red-950/10"
                    : "bg-[#11151D] border-slate-850 text-slate-400 hover:border-slate-800 hover:text-slate-200"
                }`}
                id={`error-trap-${item.id}`}
              >
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${activeErrorId === item.id ? "bg-red-500 animate-pulse" : "bg-slate-700"}`} />
                  <h4 className="text-xs font-serif font-bold text-slate-200 leading-snug">
                    {item.title}
                  </h4>
                </div>
                <p className="text-[10px] font-sans text-slate-400 mt-1.5 leading-relaxed line-clamp-2">
                  {item.summary}
                </p>
              </button>
            ))}
          </div>

          {/* Interactive Draft Sandbox: "Refinería" */}
          <div className="bg-[#11151D] border border-slate-800 rounded-xl p-5 space-y-3 shadow-inner" id="refinery-form">
            <h3 className="text-xs font-mono uppercase tracking-wider text-[#CCA352] flex items-center gap-1.5">
              <span className="text-sm">🧪</span>
              Refinería de Respuestas USS (Borradores)
            </h3>
            <p className="text-[10px] text-slate-400 leading-relaxed font-sans">
              Inserta un borrador o esbozo de respuesta a examen solemne. El asertivo filtro rector de {mentorName} lo transmutará en un fragmento de impecable y fluida dogmática.
            </p>

            <div className="space-y-2">
              <label className="text-[9px] font-mono text-slate-500 block uppercase">Asociar al Posible Conflicto:</label>
              <select
                value={selectedErrorType}
                onChange={(e) => setSelectedErrorType(e.target.value)}
                className="w-full bg-slate-950 text-xs border border-slate-800 rounded-md p-2 text-slate-350 focus:outline-none focus:ring-1 focus:ring-[#CCA352]"
                id="refinery-error-selector"
              >
                {CLASSIC_ERRORS.map((item) => (
                  <option key={item.id} value={item.title}>{item.title}</option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-[9px] font-mono text-slate-500 block uppercase">Tu Borrador Crudo:</label>
              <textarea
                value={draftSnippet}
                onChange={(e) => setDraftSnippet(e.target.value)}
                placeholder="Ej: Portales fue un dictador que quería asustar a todos y puso orden de una forma militar para que nadie protestara..."
                className="bg-slate-950 border border-slate-805 text-xs text-white p-3 rounded-lg w-full h-24 focus:outline-none focus:ring-1 focus:ring-[#CCA352]"
                id="refinery-textarea"
              />
            </div>

            <div className="flex justify-end pt-1">
              <button
                onClick={handleRefine}
                disabled={loading}
                className="bg-gradient-to-r from-red-950/60 to-slate-900 hover:to-red-900 border border-red-800/40 text-red-300 font-mono text-[10px] font-bold uppercase tracking-widest py-2 px-4 rounded-lg flex items-center gap-1.5 transition-colors disabled:opacity-50"
                id="refinery-run-btn"
              >
                {loading ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Send className="w-3 h-3" />}
                Purificar Redacción
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Comparative card mapping error or showing refinery output */}
        <div className="lg:col-span-7 space-y-6">
          {selectedErrorObj && !refineryResult && !loading && (
            <div className="bg-[#11151D] border border-slate-800 rounded-xl p-5 space-y-5 shadow-xl relative overflow-hidden" id="error-resolution-card">
              <div className="border-b border-slate-800 pb-3">
                <span className="text-[10px] font-mono text-red-400 uppercase tracking-widest font-bold">Diagnóstico de Desviación USS</span>
                <h3 className="text-base font-serif font-semibold text-white mt-1">
                  Enfoque Doctrinal del Error: "{selectedErrorObj.title}"
                </h3>
              </div>

              {/* Legal Explanation */}
              <div className="space-y-2">
                <h4 className="text-[10px] tracking-wider uppercase font-mono text-slate-450">Análisis Institucional de la Cátedra:</h4>
                <p className="text-xs text-slate-300 font-serif leading-relaxed text-justify">
                  {selectedErrorObj.doctrineText}
                </p>
              </div>

              {/* Comparative Sandbox (Bad vs Good) */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                {/* Bad response */}
                <div className="bg-red-950/10 border border-red-950/40 rounded-lg p-3.5 space-y-2">
                  <div className="flex items-center gap-1 text-[10px] uppercase font-mono font-bold text-red-400">
                    <XCircle className="w-3.5 h-3.5" />
                    Ejemplo Erróneo (Novela Histórica)
                  </div>
                  <p className="text-[11px] font-serif text-slate-400 italic leading-relaxed text-justify">
                    &ldquo;{selectedErrorObj.exampleBad}&rdquo;
                  </p>
                  <p className="text-[9px] text-red-300 font-mono leading-none bg-red-950/20 p-1.5 rounded">
                    ⚠️ NOTA ESTIMADA: 2.5 • Falta de doctrina pura y jerga técnica.
                  </p>
                </div>

                {/* Excellent response */}
                <div className="bg-[#CCA352]/5 border border-[#CCA352]/20 rounded-lg p-3.5 space-y-2">
                  <div className="flex items-center gap-1 text-[10px] uppercase font-mono font-bold text-amber-500">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#CCA352]" />
                    Ejemplo Sobresaliente (Doctrina Jurídica)
                  </div>
                  <p className="text-[11px] font-serif text-slate-300 italic leading-relaxed text-justify">
                    &ldquo;{selectedErrorObj.exampleGood}&rdquo;
                  </p>
                  <p className="text-[9px] text-[#CCA352] font-mono leading-none bg-[#CCA352]/10 p-1.5 rounded">
                    ⭐️ NOTA RECOMENDADA: 7.0 • Impecable encuadre dogmático.
                  </p>
                </div>
              </div>

              <div className="text-[10px] text-slate-500 font-mono text-center pt-2">
                Evita la narratividad lírica; el Derecho se escribe con conceptos rigurosos e instituciones claras.
              </div>
            </div>
          )}

          {/* Loading panel */}
          {loading && (
            <div className="bg-[#11151D] border border-slate-800 rounded-xl p-10 text-center h-full flex flex-col justify-center items-center" id="refinery-loader">
              <RefreshCw className="w-8 h-8 text-[#CCA352] animate-spin mb-3" />
              <p className="text-xs font-serif italic text-slate-400">
                &ldquo;Procesando tu borrador mediante el tamiz de la argumentación formal... Reformulando en latín y castellano forense bajo doctrinas de Álvaro Iriarte.&rdquo;
              </p>
            </div>
          )}

          {/* Error inside evaluation */}
          {errorMsg && !loading && (
            <div className="bg-red-950/30 border border-red-900 rounded-xl p-4 text-red-200 text-xs" id="refinery-error">
              ⚠ Error en purificación: {errorMsg}
            </div>
          )}

          {/* Refinery results showcase */}
          {refineryResult && !loading && (
            <div className="bg-[#FAF8F5] text-slate-900 border border-[#CCA352]/25 rounded-xl p-6 shadow-xl relative overflow-hidden" id="refinery-parchment">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
                <span className="font-mono text-[9px] uppercase tracking-widest text-[#BCA374] font-bold">
                  Borrador Purificado • Refinería Socrática USS
                </span>
                <button
                  onClick={() => setRefineryResult(null)}
                  className="text-xs font-mono text-slate-400 hover:text-slate-800 transition-colors uppercase font-bold"
                  id="dismiss-refinery-btn"
                >
                  Volver al Mapa de Errores ↩
                </button>
              </div>

              <div className="space-y-4 font-serif text-justify">
                <div>
                  <h4 className="text-[10px] uppercase font-mono tracking-wider text-red-800 font-bold mb-1">
                    🔍 Diagnóstico del Mentor:
                  </h4>
                  <p className="text-xs text-slate-700 leading-relaxed font-serif">
                    {refineryResult.diagnostic}
                  </p>
                </div>

                <div>
                  <h4 className="text-[10px] uppercase font-mono tracking-wider text-slate-900 font-bold mb-1">
                    📖 Sustento Doctrinal Requerido:
                  </h4>
                  <p className="text-xs text-slate-700 leading-relaxed font-serif">
                    {refineryResult.doctrineExplanation}
                  </p>
                </div>

                <div className="bg-[#CCA352]/5 border border-[#CCA352]/30 p-4 rounded-lg my-2">
                  <h4 className="text-[10px] uppercase font-mono tracking-wider text-amber-800 font-bold mb-1 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-700" />
                    Propuesta Modelada Redactada (Resultado 7.0):
                  </h4>
                  <p className="text-xs text-slate-800 leading-relaxed font-serif italic text-justify">
                    &ldquo;{refineryResult.refinedText}&rdquo;
                  </p>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-200 text-[10px] text-slate-500 font-mono text-center">
                &ldquo;El lenguaje jurídico es de carácter objetivo, conceptual y solemne.&rdquo;
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
