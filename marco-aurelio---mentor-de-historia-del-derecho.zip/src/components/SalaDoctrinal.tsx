import React, { useState } from "react";
import { Scale, BookOpen, ChevronRight, HelpCircle, RefreshCw, Send } from "lucide-react";

interface SalaDoctrinalProps {
  mentorName: string;
}

export default function SalaDoctrinal({ mentorName }: SalaDoctrinalProps) {
  const [topic, setTopic] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const keyDebatesList = [
    {
      title: "La Junta de 1810: ¿Fidelidad Real o Estrategia Independentista?",
      description: "El debate historiográfico sobre la 'máscara de Fernando VII' versus la fidelidad constitucional de los criollos."
    },
    {
      title: "El Orden Portaliano: ¿Constitucionalismo Pragmático o Dictadura Oligárquica?",
      description: "Compara la lectura conservadora/autoritaria (Góngora, Eyzaguirre) contra el análisis liberal de la Constitución de 1833."
    },
    {
      title: "El Parlamentarismo de Facto (1891-1925): ¿Parlamento Progresista u Oligarquía Inoperante?",
      description: "El encendido debate sobre si la era parlamentaria estancó la Cuestión Social o maduró la convivencia civil."
    }
  ];

  const handleFetchDebate = async (selectedTopic: string) => {
    setLoading(true);
    setErrorMsg(null);
    setResult(null);
    setTopic(selectedTopic);

    try {
      const response = await fetch("/api/mentor/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: "sala-doctrinal",
          topic: selectedTopic,
          mentorName
        })
      });

      if (!response.ok) {
        throw new Error(`Error en el servidor de debates (código ${response.status})`);
      }

      const data = await response.json();
      setResult(data.text);
    } catch (err: any) {
      setErrorMsg(err.message || "No se pudo invocar el análisis historiográfico de la Sala Doctrinal.");
    } finally {
      setLoading(false);
    }
  };

  const handleCustomQuery = () => {
    if (!topic.trim()) {
      setErrorMsg("Escribe una controversia o elige un debate institucional sugerido.");
      return;
    }
    handleFetchDebate(topic);
  };

  return (
    <div className="space-y-6" id="sala-doctrinal-panel">
      {/* Intro Block */}
      <div className="bg-[#121021] border border-[#CCA352]/20 rounded-xl p-5 shadow-lg">
        <h2 className="text-xl font-serif font-semibold text-white flex items-center gap-2">
          <Scale className="w-5 h-5 text-[#CCA352]" />
          ⚖ Sala Doctrinal: Grandes Debates Historiográficos
        </h2>
        <p className="text-xs text-slate-300 mt-1 lines-relaxed">
          En la academia USS, entendemos que el Derecho no es lineal; es fruto de tensiones sociales, filosóficas y doctrinarias. Selecciona una controversia constitucional histórica y {mentorName} confrontará las tesis en pugna, motivando tu opinión de jurista independiente.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Debates suggested panel */}
        <div className="md:col-span-5 space-y-3">
          <label className="text-[10px] font-mono uppercase tracking-widest text-slate-450 block px-1">Grandes Controversias del Pensamiento Chileno:</label>
          {keyDebatesList.map((d, index) => (
            <button
              key={index}
              onClick={() => handleFetchDebate(d.title)}
              className="w-full text-left bg-[#11151D] hover:bg-[#CCA352]/10 border border-slate-800 hover:border-[#CCA352] p-4 rounded-xl transition-all block group"
              id={`debate-btn-${index}`}
            >
              <h3 className="text-xs font-serif font-bold text-slate-200 group-hover:text-[#CCA352] transition-colors leading-snug">
                {d.title}
              </h3>
              <p className="text-[10px] font-sans text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                {d.description}
              </p>
              <div className="flex items-center gap-1 font-mono text-[9px] text-[#BCA374] mt-2 group-hover:translate-x-1 transition-transform">
                <span>Entrar a debatir</span>
                <ChevronRight className="w-3 h-3" />
              </div>
            </button>
          ))}

          {/* Custom Input */}
          <div className="bg-[#11151D] border border-slate-800 rounded-xl p-4 space-y-3" id="custom-debate-prompt-box">
            <label className="text-[10px] font-mono uppercase tracking-wider text-slate-450 block">Plantear Controversia Personalizada:</label>
            <textarea
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="Ej: ¿Tiene sustento jurídico la postulación absolutista en las Leyes de Indias o prevaleció el iusnaturalismo racional?"
              className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs font-serif text-white h-20 w-full focus:outline-none focus:ring-1 focus:ring-[#CCA352]"
              id="custom-debate-text"
            />
            <div className="flex justify-end">
              <button
                onClick={handleCustomQuery}
                disabled={loading}
                className="bg-[#CCA352]/20 hover:bg-[#CCA352] border border-[#CCA352]/40 hover:border-[#CCA352] text-[#CCA352] hover:text-slate-950 transition-colors uppercase font-mono font-bold tracking-wider text-[10px] px-3.5 py-1.5 rounded-lg flex items-center gap-1.5"
                id="custom-debate-btn"
              >
                {loading ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Send className="w-3 h-3" />}
                Confrontar Doctrinas
              </button>
            </div>
          </div>
        </div>

        {/* Output Panel on Right */}
        <div className="md:col-span-7">
          {loading && (
            <div className="bg-[#11151D] border border-slate-800 rounded-xl p-10 text-center h-full flex flex-col justify-center items-center" id="debate-loader">
              <RefreshCw className="w-9 h-9 text-[#CCA352] animate-spin mb-3" />
              <p className="text-xs font-serif italic text-slate-400">
                &ldquo;Confrontando las corrientes historiográficas liberales de Barros Arana con el realismo analítico de Heise o Góngora... Redactando balance académico.&rdquo;
              </p>
            </div>
          )}

          {errorMsg && !loading && (
            <div className="bg-red-950/40 border border-red-950 rounded-xl p-4 text-red-200 text-xs" id="debate-error">
              ⚠ Error: {errorMsg}
            </div>
          )}

          {result && !loading && (
            <div className="bg-[#FAF8F5] text-slate-900 border border-[#CCA352]/20 rounded-xl p-6 shadow-xl relative overflow-hidden" id="debate-parchment">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
                <span className="font-mono text-[10px] uppercase tracking-widest text-[#BCA374] font-bold">
                  Confrontación Crítica de Corrientes USS
                </span>
                <span className="text-xs italic text-slate-500">Cátedra Doctrinal</span>
              </div>

              <div className="prose prose-sm max-w-none text-slate-800 space-y-4 font-serif">
                {result.split("\n").map((line, idx) => {
                  const trimmed = line.trim();
                  if (!trimmed) return <div key={idx} className="h-1.5" />;

                  // Format standard sections or subheaders
                  if (trimmed.startsWith("1.") || trimmed.startsWith("2.") || trimmed.startsWith("3.") || trimmed.startsWith("CONFRONTACIÓN") || trimmed.startsWith("ARGUMENTACIÓN") || trimmed.startsWith("REFLEXIÓN")) {
                    return (
                      <h4 key={idx} className="text-sm font-bold text-slate-900 mt-4 mb-2 border-b border-amber-200/50 pb-1 flex items-center gap-1.5">
                        <ChevronRight className="w-3.5 h-3.5 text-amber-700" />
                        {trimmed}
                      </h4>
                    );
                  }

                  if (trimmed.includes("¿") || trimmed.startsWith("PREGUNTA SOCRÁTICA")) {
                    return (
                      <div key={idx} className="my-5 p-4 bg-amber-50 border-l-4 border-[#CCA352] rounded-r-lg text-slate-800 text-xs font-serif leading-relaxed">
                        <p className="font-bold font-mono tracking-widest text-[9px] uppercase text-amber-800 mb-1 flex items-center gap-1">
                          <HelpCircle className="w-3.5 h-3.5 text-amber-700" />
                          PROBLEMATIZACIÓN DEL MENTOR:
                        </p>
                        {trimmed}
                      </div>
                    );
                  }

                  return <p key={idx} className="text-xs text-slate-700 leading-relaxed text-justify">{trimmed}</p>;
                })}
              </div>

              <div className="mt-6 pt-4 border-t border-slate-200 text-[10px] text-slate-500 font-mono text-center">
                &ldquo;Formando independencia intelectual y pensamiento forense en derecho de primer nivel.&rdquo;
              </div>
            </div>
          )}

          {!result && !loading && (
            <div className="h-full min-h-[300px] flex flex-col justify-center items-center border border-dashed border-slate-800 rounded-xl p-8 text-[#CCA352]/40 font-serif text-center" id="debate-empty-state">
              <Scale className="w-12 h-12 mb-3 text-slate-700" />
              <h3>Bienvenido al Claustro Doctrinal chileno</h3>
              <p className="text-[11px] text-slate-500 font-sans mt-1 max-w-sm">
                Selecciona una de las controversias de la izquierda para ver el debate con citas académicas estructuradas de inmediato.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
