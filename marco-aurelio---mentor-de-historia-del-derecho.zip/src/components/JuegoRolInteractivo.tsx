import React, { useState, useEffect } from "react";
import { 
  Award, 
  HelpCircle, 
  ArrowRight, 
  RefreshCw, 
  Sparkles, 
  RotateCcw, 
  CheckCircle, 
  ChevronRight, 
  PenTool, 
  BookOpen, 
  Check, 
  AlertTriangle,
  Flame,
  User,
  Activity
} from "lucide-react";
import { SOLEMN_RECUPERATIVA_QUESTIONS, APUNTES_CHAPTERS, QuestionData } from "../dataNotes";

interface JuegoRolInteractivoProps {
  mentorName: string;
}

interface PerformanceHistoryItem {
  questionId: number;
  questionText: string;
  topic: string;
  studentAnswer: string;
  score: number;
  complement: string;
}

export default function JuegoRolInteractivo({ mentorName }: JuegoRolInteractivoProps) {
  // Gameplay Stages: "setup" | "active" | "evaluation" | "finished"
  const [stage, setStage] = useState<"setup" | "active" | "evaluation" | "finished">("setup");
  
  // Game Settings
  const [totalQuestionsLimit, setTotalQuestionsLimit] = useState<number>(10); // Options: 5, 10, 15, 20
  const [selectedTopic, setSelectedTopic] = useState<string>("Todos");
  
  // Game Session States
  const [sessionQuestions, setSessionQuestions] = useState<QuestionData[]>([]);
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [currentAnswer, setCurrentAnswer] = useState<string>("");
  const [history, setHistory] = useState<PerformanceHistoryItem[]>([]);
  
  // Mentor Live Complement State
  const [loading, setLoading] = useState<boolean>(false);
  const [currentAssessment, setCurrentAssessment] = useState<{
    score: number;
    feedback: string;
    complement: string;
    criticalKeypoint: string;
  } | null>(null);

  // Filter distinct topics for the setup
  const topicsList = ["Todos", ...Array.from(new Set(SOLEMN_RECUPERATIVA_QUESTIONS.map(q => q.topic)))];

  // Initialize Game Session
  const handleStartRolePlay = () => {
    // Filter questions by topic first
    let filtered = [...SOLEMN_RECUPERATIVA_QUESTIONS];
    if (selectedTopic !== "Todos") {
      filtered = filtered.filter(q => q.topic === selectedTopic);
    }
    
    // Shuffle questions randomly
    const shuffled = filtered.sort(() => 0.5 - Math.random());
    
    // Slice according to limit
    const selected = shuffled.slice(0, Math.min(totalQuestionsLimit, filtered.length));
    
    setSessionQuestions(selected);
    setCurrentIdx(0);
    setCurrentAnswer("");
    setHistory([]);
    setCurrentAssessment(null);
    setStage("active");
  };

  // Evaluate Active Question via API
  const handleEvaluateAnswer = async () => {
    if (!currentAnswer.trim()) return;
    
    setLoading(true);
    setCurrentAssessment(null);
    
    const activeQuestion = sessionQuestions[currentIdx];
    
    try {
      const customPrompt = `Actúa como ${mentorName}, un catedrático experto de Historia del Derecho de la USS (Álvaro Iriarte). 
      El alumno está realizando un juego de rol de preguntas y su objetivo es rendir con excelencia el Solemne. 

      PREGUNTA EN CURSO: "${activeQuestion.id}. ${activeQuestion.question}"
      TEMA ASOCIADO: "${activeQuestion.topic}"
      PAUTA COMPLEMENTARIA: "${activeQuestion.summaryTip}"
      RESPUESTA ESCRITA POR EL ESTUDIANTE:
      "${currentAnswer}"

      Analiza minuciosamente la respuesta del alumno y genera un dictamen pedagógico en formato JSON estricto con las siguientes directrices:
      1. Califica de 1.0 a 7.0 (nota individual USS, usa decimales como 4.5, 6.2, etc.). Considera: si omite la doctrina, penalízalo; si usa el vocabulario del curso, prémialo.
      2. En la propiedad "feedback", dale un veredicto socrático y asertivo corto (máximo 4 líneas) explicándole qué hizo bien y qué le faltó en su argumentación.
      3. En la propiedad "complement", COMPLEMENTA Y ENRIQUECE su respuesta ("complementas cada respuesta antes de pasar a la siguiente"). Es decir, escribe tú la respuesta ideal impecable o el complemento doctrinal que complete el vacío del alumno para que el alumno aprenda el marco conceptual exacto de la cátedra de Álvaro Iriarte.
      4. En la propiedad "criticalKeypoint", resume un concepto clave obligatorio que NO se le debe olvidar en el examen final bajo ninguna circunstancia.

      Responde únicamente en un formato JSON plano, con estas claves exactas:
      {
        "score": 6.1,
        "feedback": "Aquí tu veredicto...",
        "complement": "Aquí tu detallado complemento doctrinal...",
        "criticalKeypoint": "Aquí la clave de examen..."
      }`;

      const response = await fetch("/api/mentor/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: "custom-query",
          customPrompt,
          mentorName
        })
      });

      if (!response.ok) {
        throw new Error("No pudimos consultar con los examinadores USS.");
      }

      const data = await response.json();
      
      // Parse clean JSON output
      let parsedResponse;
      try {
        // Handle markdown JSON formatting if models return wrapping
        let cleanText = data.text.trim();
        if (cleanText.startsWith("```json")) {
          cleanText = cleanText.substring(7);
        }
        if (cleanText.startsWith("```")) {
          cleanText = cleanText.substring(3);
        }
        if (cleanText.endsWith("```")) {
          cleanText = cleanText.substring(0, cleanText.length - 3);
        }
        parsedResponse = JSON.parse(cleanText.trim());
      } catch (e) {
        // Fallback parse if layout failed
        parsedResponse = {
          score: 4.5,
          feedback: "Tu respuesta demuestra comprensión general, aunque requiere mayor estructuración jurídica.",
          complement: "Información complementaria doctrinal: " + activeQuestion.summaryTip,
          criticalKeypoint: "Recuerda fundamentar siempre basándote en fuentes, como las Leyes de Partida o Constitución de 1833."
        };
      }

      setCurrentAssessment(parsedResponse);
      setStage("evaluation");
      
      // Record in history
      const record: PerformanceHistoryItem = {
        questionId: activeQuestion.id,
        questionText: activeQuestion.question,
        topic: activeQuestion.topic,
        studentAnswer: currentAnswer,
        score: parsedResponse.score,
        complement: parsedResponse.complement
      };
      
      setHistory(prev => [...prev, record]);

    } catch (error) {
      console.error(error);
      // Local recovery mock complement so the game never freezes
      const activeQuestion = sessionQuestions[currentIdx];
      const parsedRecovered = {
        score: 5.0,
        feedback: "Tu respuesta aborda la esfera histórica, pero requiere citar doctrinas directas de la cátedra para alcanzar el 7.0.",
        complement: `Complemento de cátedra: ${activeQuestion.summaryTip}. Recuerda que Russel Kirk y Álvaro D'Ors plantean la co-existencia de la constitución histórica como un organismo vivo frente al abstraccionismo racional de las cartas escritas.`,
        criticalKeypoint: "Evita la narrativa descriptiva simple: prefiere siempre el análisis dogmático-institucional."
      };
      setCurrentAssessment(parsedRecovered);
      setStage("evaluation");
      
      setHistory(prev => [...prev, {
        questionId: activeQuestion.id,
        questionText: activeQuestion.question,
        topic: activeQuestion.topic,
        studentAnswer: currentAnswer,
        score: 5.0,
        complement: parsedRecovered.complement
      }]);
    } finally {
      setLoading(false);
    }
  };

  // Move forward to the next question
  const handleNextStep = () => {
    if (currentIdx + 1 >= sessionQuestions.length) {
      setStage("finished");
    } else {
      setCurrentIdx(prev => prev + 1);
      setCurrentAnswer("");
      setCurrentAssessment(null);
      setStage("active");
    }
  };

  // Helper score badges colors
  const getScoreBadgeColor = (score: number) => {
    if (score >= 6.0) return "bg-emerald-950/40 border-emerald-500 text-emerald-400";
    if (score >= 4.0) return "bg-blue-950/40 border-blue-500 text-blue-400";
    return "bg-rose-950/40 border-rose-500 text-rose-400";
  };

  // Final average GPA calculator
  const calculateGPA = () => {
    if (history.length === 0) return 1.0;
    const sum = history.reduce((acc, curr) => acc + curr.score, 0);
    return parseFloat((sum / history.length).toFixed(1));
  };

  const finalGPA = calculateGPA();

  return (
    <div className="space-y-6" id="interactive-role-play-classroom">
      
      {/* Dynamic Header Block with limits */}
      <div className="bg-[#0B1520] border border-[#CCA352]/20 rounded-xl p-5 shadow-lg relative overflow-hidden" id="interactive-role-play-header">
        <div className="absolute right-0 top-0 text-[#CCA352]/5 text-9xl font-serif pointer-events-none select-none">
          {totalQuestionsLimit}
        </div>
        <div className="flex items-center gap-3">
          <Flame className="w-6 h-6 text-[#CCA352] animate-pulse" />
          <div>
            <h2 className="text-xl font-serif font-semibold text-white">
              Cuestionario & Role Playing Interactivo
            </h2>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              APLICACIÓN PERSONALIZADA • EVALUACIÓN Y COMPLEMENTACIÓN EN TIEMPO REAL
            </p>
          </div>
        </div>
        <p className="text-xs text-slate-300 mt-2 leading-relaxed">
          Pon a prueba tus conocimientos con una sesión interactiva estructurada del Cedulario USS USS.
          Elige una duración (<strong>máximo de 20 preguntas</strong>), responde con tus palabras y {mentorName} complementará tu respuesta explicándote a fondo la verdad doctrinal antes de que puedas progresar.
        </p>
      </div>

      {/* STAGE A: SETUP SCREEN */}
      {stage === "setup" && (
        <div className="bg-[#11151D] border border-slate-800 rounded-xl p-6 md:p-8 space-y-6" id="rp-setup-screen">
          <h3 className="text-base font-serif font-bold text-white border-b border-slate-800 pb-3 flex items-center gap-2">
            <Activity className="w-5 h-5 text-[#CCA352]" />
            Configurar Partida de Evaluación de Rol
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Limit Selector */}
            <div className="space-y-3">
              <label className="block text-xs font-mono uppercase tracking-wider text-slate-400">
                1. Selecciona el número de preguntas (Máx. 20):
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[5, 10, 15, 20].map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => setTotalQuestionsLimit(num)}
                    className={`py-3 rounded-lg border text-xs font-mono font-bold transition-all ${
                      totalQuestionsLimit === num
                        ? "bg-[#CCA352]/10 border-[#CCA352] text-[#CCA352] shadow-md shadow-[#CCA352]/5 scale-105"
                        : "bg-slate-950 border-slate-850 text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    {num} Pregs
                  </button>
                ))}
              </div>
              <p className="text-[10px] text-slate-500">
                La comisión seleccionará aleatoriamente un set balanceado de preguntas de entre el cedulario USS para cumplir con el límite configurado.
              </p>
            </div>

            {/* Scope / Topic Selector */}
            <div className="space-y-3">
              <label className="block text-xs font-mono uppercase tracking-wider text-slate-400">
                2. Historial de Materias o Temas a evaluar:
              </label>
              <select
                value={selectedTopic}
                onChange={(e) => setSelectedTopic(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 text-xs text-white rounded-lg px-3 py-3 focus:ring-1 focus:ring-[#CCA352] focus:outline-none"
              >
                {topicsList.map((topic, i) => (
                  <option key={i} value={topic}>
                    {topic === "Todos" ? "📚 Todos los Capítulos del Semestre" : `🎯 ${topic}`}
                  </option>
                ))}
              </select>
              <p className="text-[10px] text-slate-500">
                Filtra la simulación para enfocarte en temas precisos como el Pactismo de 1810, Leyes de Toro, Constitución del 33 o la de 1925.
              </p>
            </div>
          </div>

          {/* Quick instructions */}
          <div className="bg-slate-950/55 rounded-lg border border-slate-850 p-4 space-y-2">
            <h4 className="text-xs font-sans font-bold text-slate-300">¿Cómo funciona esta simulación interactiva?</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-[11px] text-slate-400">
              <div className="flex gap-2 items-start">
                <span className="text-[#CCA352] font-bold">1.</span>
                <span>Recibes una pregunta del cedulario redactada formalmente por el programa oficial de Álvaro Iriarte Baron.</span>
              </div>
              <div className="flex gap-2 items-start">
                <span className="text-[#CCA352] font-bold">2.</span>
                <span>Sometes tu respuesta en lenguaje explicativo o forense para recibir tu calificación en formato chileno (1.0 - 7.0).</span>
              </div>
              <div className="flex gap-2 items-start">
                <span className="text-[#CCA352] font-bold">3.</span>
                <span><strong>El Mentor detalla su complemento doctrinal</strong>, estructurando el vacío académico descubierto antes de permitirte seguir.</span>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 flex justify-end">
            <button
              onClick={handleStartRolePlay}
              className="bg-gradient-to-r from-[#CCA352] to-[#BCA374] text-slate-950 font-mono text-xs uppercase tracking-wider font-bold px-8 py-3.5 rounded-xl shadow-lg hover:brightness-105 transition-all flex items-center gap-2"
              id="start-roleplay-session-btn"
            >
              <Sparkles className="w-4 h-4" />
              Iniciar Comisión de Role-Playing
            </button>
          </div>
        </div>
      )}

      {/* STAGE B: ACTIVE QUESTION SYSTEM */}
      {stage === "active" && (
        <div className="bg-[#11151D] border border-slate-800 rounded-xl p-5 md:p-6 space-y-5" id="rp-active-question-screen">
          
          {/* Top Progress bar */}
          <div className="flex justify-between items-center bg-slate-950 border border-slate-850 p-3 rounded-lg">
            <div className="flex items-center gap-3">
              <span className="text-xs text-[#CCA352] font-mono font-bold uppercase tracking-widest">
                PREGUNTA {currentIdx + 1} de {sessionQuestions.length}
              </span>
              <div className="hidden sm:flex h-1.5 w-32 bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-[#CCA352]" 
                  style={{ width: `${((currentIdx + 1) / sessionQuestions.length) * 100}%` }}
                />
              </div>
            </div>
            <span className="text-[10px] font-mono text-slate-400 uppercase">
              Ramo: Historia del Derecho • Cátedra USS
            </span>
          </div>

          {/* Question display card */}
          <div className="bg-slate-950 border border-slate-850 p-5 rounded-lg space-y-2">
            <span className="text-[9px] font-mono uppercase tracking-widest text-slate-500 flex items-center gap-1.5">
              <HelpCircle className="w-3.5 h-3.5 text-[#CCA352]" />
              EXAMINA LA PREGUNTA DEL CEDULARIO OFICIAL
            </span>
            <h3 className="text-base md:text-lg font-serif font-bold text-white leading-snug">
              {sessionQuestions[currentIdx]?.question}
            </h3>
            <span className="inline-block text-[9px] font-mono uppercase bg-slate-900 border border-slate-800 text-[#CCA352] px-2 py-0.5 rounded mt-2">
              Concepto: {sessionQuestions[currentIdx]?.topic}
            </span>
          </div>

          {/* Answer formulation */}
          <div className="space-y-2">
            <label className="block text-xs font-mono uppercase tracking-wider text-slate-400">
              ✍️ Tu respuesta pedagógica o defensa doctrinal:
            </label>
            <textarea
              className="w-full h-44 bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs text-slate-200 font-serif leading-relaxed focus:ring-1 focus:ring-[#CCA352] focus:outline-none"
              placeholder="Desarrolla aquí tu respuesta fundamentada. Evita el relato histórico lineal simple: argumenta desde el punto de vista doctrinal, el pactismo, las ordenanzas reales, o el control de constitucionalidad..."
              value={currentAnswer}
              onChange={(e) => setCurrentAnswer(e.target.value)}
              disabled={loading}
              id="roleplay-answer-textarea"
            />
            <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono">
              <span>{currentAnswer.trim().length} caracteres redactados</span>
              <span className="italic">Examine con calma ante de someter la defensa.</span>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 flex justify-between flex-wrap gap-2">
            <button
              onClick={() => setStage("setup")}
              className="bg-slate-900 hover:bg-slate-850 text-slate-400 font-mono text-xs uppercase px-4 py-3 rounded-lg border border-slate-800 transition-colors"
            >
              Regresar al Menú
            </button>
            <button
              onClick={handleEvaluateAnswer}
              disabled={loading || !currentAnswer.trim()}
              className="bg-gradient-to-r from-[#CCA352] to-[#BCA374] text-slate-950 font-mono text-xs uppercase tracking-wider font-bold px-6 py-3 rounded-xl disabled:opacity-40 transition-all shadow-md flex items-center justify-center gap-2"
              id="submit-roleplay-answer-btn"
            >
              {loading ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <CheckCircle className="w-4 h-4" />
              )}
              Someter a Evaluación de Cátedra
            </button>
          </div>
        </div>
      )}

      {/* STAGE C: INTERACTIVE COMPLEMENT & EVALUATION SCREEN */}
      {stage === "evaluation" && currentAssessment && (
        <div className="space-y-6" id="rp-evaluation-complement-screen">
          
          {/* Header showing student score */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-stretch">
            
            {/* Left box: Score and quick overview */}
            <div className="md:col-span-4 bg-[#11151D] border border-slate-800 rounded-xl p-5 flex flex-col justify-between text-center relative overflow-hidden">
              <div className="space-y-2">
                <span className="text-[10px] font-mono uppercase tracking-widest text-slate-500 block">
                  Evaluación USS Exigida
                </span>
                
                {/* Large visual grade badge */}
                <div className="my-3 flex justify-center">
                  <div className={`w-20 h-20 rounded-full border-2 flex flex-col items-center justify-center shadow-lg ${getScoreBadgeBadge(currentAssessment.score)}`}>
                    <span className="text-2xl font-serif font-bold leading-none">{currentAssessment.score.toFixed(1)}</span>
                    <span className="text-[8px] font-mono uppercase tracking-wider mt-1">Examen USS</span>
                  </div>
                </div>
                
                <span className={`inline-block text-[10px] font-mono uppercase tracking-widest px-2.5 py-1 rounded-full border ${currentAssessment.score >= 4.0 ? "text-emerald-400 border-emerald-800 bg-emerald-950/20" : "text-rose-400 border-rose-800 bg-rose-950/20"}`}>
                  {currentAssessment.score >= 4.0 ? "Aprobado Justo" : "Reprobado"}
                </span>
              </div>

              <div className="border-t border-slate-850 pt-3 mt-4 text-[10px] text-slate-400 font-mono leading-relaxed">
                Evaluación ponderada por {mentorName}.
              </div>
            </div>

            {/* Right box: Mentor Socratic Feedback critique */}
            <div className="md:col-span-8 bg-[#11151D] border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-[#CCA352]" />
                  <span className="text-xs font-mono uppercase font-bold text-white tracking-widest">
                    Veredicto Pedagógico del Mentor
                  </span>
                </div>
                <p className="text-xs text-slate-300 font-serif leading-relaxed text-justify italic">
                  &ldquo;{currentAssessment.feedback}&rdquo;
                </p>
              </div>

              {/* Critical keypoint warning banner */}
              {currentAssessment.criticalKeypoint && (
                <div className="bg-amber-950/20 border border-amber-900/40 rounded-lg p-3 mt-4 flex gap-3 text-[11px] text-amber-300 items-start">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />
                  <div>
                    <span className="font-bold underline block font-mono uppercase text-[9px] tracking-wider mb-0.5">⚠️ No Olvidar en el Solemne:</span>
                    <span className="font-serif leading-normal">{currentAssessment.criticalKeypoint}</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* ACTIVE NOBLE PARCHMENT: COMPLEMENT & ENRICHMENT */}
          <div className="bg-[#FAF8F5] text-slate-900 border border-amber-300/40 rounded-xl p-6 shadow-2xl space-y-4" id="noble-complement-parchment">
            <div className="border-b border-amber-200 pb-3 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-widest text-[#BCA374] font-bold block">
                  LECCIÓN COMPLEMENTARIA DE CÁTEDRA USS
                </span>
                <h3 className="text-sm font-serif font-semibold text-slate-800">
                  Resumen de la pregunta, argumentos constitucionales y doctrina que debiste argumentar
                </h3>
              </div>
              <span className="text-[9px] font-mono bg-amber-100 text-[#BCA374] border border-[#BCA374]/30 px-2 py-0.5 rounded font-bold">
                ENRIQUECIMIENTO COGNITIVO
              </span>
            </div>

            <p className="text-xs text-slate-700 leading-relaxed font-serif text-justify bg-amber-50/50 p-4 rounded-lg border border-amber-100 italic">
              {currentAssessment.complement}
            </p>

            <div className="text-[10px] text-slate-400 font-mono text-center pt-2">
              Haz internalizado el complemento doctrinal. Ahora estás listo para someterte a la siguiente pregunta del examen.
            </div>
          </div>

          {/* Actions to proceed */}
          <div className="flex justify-end pt-2">
            <button
              onClick={handleNextStep}
              className="bg-gradient-to-r from-slate-900 to-slate-850 hover:to-slate-800 border border-slate-700 text-[#CCA352] font-mono text-xs uppercase tracking-wider font-bold px-8 py-4 rounded-xl flex items-center justify-center gap-2 transition-all shadow-md"
              id="proceed-to-next-roleplay-question-btn"
            >
              <span>Avanzar a la Siguiente Pregunta</span>
              <ChevronRight className="w-4 h-4 text-[#CCA352]" />
            </button>
          </div>
        </div>
      )}

      {/* STAGE D: FINISHED SUMMARY SCREEN */}
      {stage === "finished" && (
        <div className="bg-[#11151D] border border-slate-800 rounded-xl p-6 md:p-8 space-y-6" id="rp-finished-screen">
          <div className="text-center space-y-3 pb-6 border-b border-slate-800">
            <div className="inline-flex justify-center items-center w-14 h-14 bg-[#CCA352]/10 border border-[#CCA352] rounded-full text-2xl text-[#CCA352] mb-1 animate-bounce">
              🎓
            </div>
            <h3 className="text-xl font-serif font-bold text-white">Comisión de Role-Playing Finalizada</h3>
            <p className="text-xs text-slate-400 font-mono tracking-wider">
              INFORME DE RENDIMIENTO ACADÉMICO USS
            </p>
          </div>

          {/* GPA Score Board banner */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center bg-slate-950/60 border border-slate-850 p-6 rounded-xl">
            <div className="text-center md:text-left space-y-1">
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest block">Nota Final Ponderada</span>
              <span className="text-4xl font-serif font-black text-[#CCA352] block" id="final-gpa-display">
                {finalGPA.toFixed(1)}
              </span>
            </div>

            <div className="text-center space-y-2">
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest block">Veredicto de la Comisión</span>
              <span className={`inline-block px-4 py-1 rounded-full text-xs font-mono uppercase font-bold border ${finalGPA >= 4.0 ? "text-emerald-400 border-emerald-800 bg-emerald-950/20" : "text-rose-400 border-rose-800 bg-rose-950/20"}`}>
                {finalGPA >= 4.0 ? "Aprobado de Cátedra" : "Reprobado Académico"}
              </span>
            </div>

            <div className="text-center md:text-right space-y-1">
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest block">Preguntas Evaluadas</span>
              <span className="text-xl font-mono font-bold text-white">
                {history.length} / {totalQuestionsLimit}
              </span>
            </div>
          </div>

          {/* Detailed answers historic timeline with complements */}
          <div className="space-y-4">
            <h4 className="text-xs font-mono uppercase tracking-wider text-[#BCA374] font-bold">
              Historial de Preguntas, Calificaciones y Respuestas evaluadas:
            </h4>
            
            <div className="space-y-4 max-h-[350px] overflow-y-auto pr-1">
              {history.map((record, index) => (
                <div key={index} className="bg-slate-950/40 border border-slate-900 rounded-lg p-4 space-y-3 text-justify">
                  <div className="flex justify-between items-start gap-4 flex-wrap border-b border-slate-900 pb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-[#CCA352] bg-slate-900 border border-slate-850 shrink-0 h-6 w-6 rounded-full flex items-center justify-center">
                        {index + 1}
                      </span>
                      <h5 className="text-xs font-serif font-bold text-white line-clamp-1">
                        {record.questionText}
                      </h5>
                    </div>
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded border font-semibold ${getScoreBadgeBadge(record.score)}`}>
                      Nota: {record.score.toFixed(1)}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-serif">
                    <div className="space-y-1">
                      <span className="text-[9px] font-mono text-slate-500 uppercase block">Tu Argumentación escrita:</span>
                      <p className="text-slate-300 italic text-justify leading-relaxed">&ldquo;{record.studentAnswer}&rdquo;</p>
                    </div>
                    <div className="space-y-1 p-2.5 bg-slate-950/20 border border-slate-900/50 rounded">
                      <span className="text-[10px] font-mono text-[#CCA352] uppercase block">Complemento de {mentorName}:</span>
                      <p className="text-slate-200 text-justify leading-relaxed line-clamp-5">{record.complement}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Restart Controls */}
          <div className="pt-6 border-t border-slate-800 flex justify-end">
            <button
              onClick={() => setStage("setup")}
              className="bg-[#CCA352] hover:bg-[#BCA374] text-slate-950 font-mono text-xs uppercase tracking-wider font-bold px-8 py-3.5 rounded-xl shadow-lg transition-colors flex items-center gap-2"
              id="restart-roleplay-session-btn"
            >
              <RotateCcw className="w-4 h-4" />
              Nueva Sesión de Role Playing
            </button>
          </div>
        </div>
      )}

    </div>
  );
}

// Inline helper to get score badges styles since TypeScript component scoping requires declaration mapping
function getScoreBadgeBadge(score: number): string {
  if (score >= 6.0) return "bg-emerald-950/40 border-emerald-500 text-emerald-400";
  if (score >= 4.0) return "bg-blue-950/40 border-slate-700 text-blue-300";
  return "bg-rose-950/40 border-rose-500 text-rose-400";
}
