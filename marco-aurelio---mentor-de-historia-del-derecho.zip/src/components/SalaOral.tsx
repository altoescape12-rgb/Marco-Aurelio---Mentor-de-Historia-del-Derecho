import React, { useState } from "react";
import { GraduationCap, Award, RefreshCw, AlertTriangle, Send, Scroll, Compass, Star, ChevronRight } from "lucide-react";
import { OralExamState } from "../types";

interface SalaOralProps {
  mentorName: string;
}

const TOPIC_SUGGESTIONS = [
  "General / Todo el Ramo",
  "Pactismo y Retroversión de Soberanía",
  "El Ensayo Moralista de 1823",
  "Régimen Portaliano y Constitución de 1833",
  "Parlamentarismo Chileno y Guerra Civil de 1891",
  "La Cuestión Social y la Constitución de 1925"
];

export default function SalaOral({ mentorName }: SalaOralProps) {
  const [exam, setExam] = useState<OralExamState>({
    currentQuestionIndex: 0,
    examHistory: [],
    currentQuestion: null,
    welcomeMessage: null,
    selectedTopic: "General / Todo el Ramo",
    difficulty: "solemne",
    isStarted: false,
    isFinished: false,
    scoreAvg: 1.0,
    finalSpeech: null,
    strongPoints: [],
    weakPoints: []
  });

  const [studentAnswer, setStudentAnswer] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const startExam = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const response = await fetch("/api/mentor/oral-exam", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          difficulty: exam.difficulty,
          currentQuestionIndex: 0,
          examHistory: [],
          selectedSubTopic: exam.selectedTopic === "General / Todo el Ramo" ? null : exam.selectedTopic,
          mentorName
        })
      });

      if (!response.ok) {
        throw new Error(`No se pudo iniciar la Sala Oral en este momento (código ${response.status})`);
      }

      const data = await response.json();

      setExam(prev => ({
        ...prev,
        isStarted: true,
        currentQuestionIndex: 1,
        currentQuestion: data.question,
        welcomeMessage: data.welcomeMessage,
        examHistory: [],
        isFinished: false,
        finalSpeech: null
      }));
      setStudentAnswer("");
    } catch (err: any) {
      setErrorMsg(err.message || "Error al conectar con el servidor.");
    } finally {
      setLoading(false);
    }
  };

  const submitAnswer = async () => {
    if (!studentAnswer.trim()) {
      setErrorMsg("Debe formular una respuesta jurídica para ser evaluado.");
      return;
    }

    setLoading(true);
    setErrorMsg(null);

    try {
      // Append the fake current question to examHistory so server can evaluate it
      const currentHistory = [...exam.examHistory];
      const unansweredObj = {
        question: exam.currentQuestion || "",
        answer: studentAnswer,
        score: 4.0, // default, will be overridden
        feedback: "",
        errorsDetected: []
      };

      const requestHistory = [...currentHistory, unansweredObj];

      const response = await fetch("/api/mentor/oral-exam", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          difficulty: exam.difficulty,
          currentQuestionIndex: exam.currentQuestionIndex,
          examHistory: requestHistory,
          studentAnswer,
          selectedSubTopic: exam.selectedTopic === "General / Todo el Ramo" ? null : exam.selectedTopic,
          mentorName
        })
      });

      if (!response.ok) {
        throw new Error(`Error en la evaluación del examen oral (código ${response.status})`);
      }

      const data = await response.json();

      const updatedHistoryItem = {
        question: exam.currentQuestion || "",
        answer: studentAnswer,
        score: data.assessment?.score || 4.0,
        feedback: data.assessment?.feedback || "Sin feedback",
        errorsDetected: data.assessment?.errorsDetected || []
      };

      const updatedHistory = [...exam.examHistory, updatedHistoryItem];

      const isFinishedNow = data.assessment?.isTerminated || exam.currentQuestionIndex >= 5;

      if (isFinishedNow) {
        // Calculate average score
        const total = updatedHistory.reduce((acc, curr) => acc + curr.score, 0);
        const avg = parseFloat((total / updatedHistory.length).toFixed(1));

        setExam(prev => ({
          ...prev,
          examHistory: updatedHistory,
          isFinished: true,
          scoreAvg: data.finalAssessment?.finalGrade || avg,
          finalSpeech: data.finalAssessment?.closingSpeech || "La sesión de comisión oral ha concluido formalmente.",
          strongPoints: data.finalAssessment?.strongPoints || ["Asimilación básica"],
          weakPoints: data.finalAssessment?.weakPoints || ["Imprecisiones de redacción"]
        }));
      } else {
        setExam(prev => ({
          ...prev,
          currentQuestionIndex: prev.currentQuestionIndex + 1,
          currentQuestion: data.nextQuestion || "Explique el siguiente hito...",
          examHistory: updatedHistory
        }));
      }

      setStudentAnswer("");
    } catch (err: any) {
      setErrorMsg(err.message || "Error al responder en el examen.");
    } finally {
      setLoading(false);
    }
  };

  const scoreColor = (score: number) => {
    if (score >= 6.0) return "text-emerald-400 border-emerald-900 bg-emerald-950/20";
    if (score >= 4.0) return "text-amber-400 border-amber-900 bg-amber-950/20";
    return "text-red-400 border-red-950 bg-red-950/25";
  };

  return (
    <div className="space-y-6" id="sala-oral-panel">
      {/* Intro Header */}
      <div className="bg-[#1C1810] border border-[#CCA352]/20 rounded-xl p-5 shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 py-2 px-4 text-[10px] font-mono tracking-widest bg-amber-950/50 text-[#CCA352] border-bl rounded-bl border-[#CCA352]/20 border-l border-b">
          EXAMEN SIMULADO S-2026
        </div>
        <h2 className="text-xl font-serif font-semibold text-white flex items-center gap-2">
          <GraduationCap className="w-5.5 h-5.5 text-[#CCA352]" />
          🎓 Sala Oral USS: Role Playing y Comisión de Solemnes
        </h2>
        <p className="text-xs text-slate-300 mt-1 lines-relaxed">
          Enfréntate a una defensa oral con {mentorName} en personaje formal. Evaluará tus respuestas en la escala chilena (1.0 a 7.0), medirá imprecisiones y te interrogará de manera adaptativa. ¡Prepara tus argumentos antes de rendir!
        </p>
      </div>

      {errorMsg && (
        <div className="bg-red-950/40 border border-red-950 p-4 rounded-xl text-red-200 text-xs flex gap-2 items-center" id="oral-error">
          <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
          <p>{errorMsg}</p>
        </div>
      )}

      {/* BEFORE START DESIGN BOARD */}
      {!exam.isStarted ? (
        <div className="bg-[#11151D] border border-slate-800 rounded-xl p-6 space-y-6 shadow-xl" id="oral-configurations">
          <h3 className="text-sm font-serif font-semibold text-[#CCA352] border-b border-slate-800 pb-3">
            Parámetros de la Comisión Evaluadora:
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Topic Select */}
            <div className="space-y-2">
              <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">Selecciona Unidad de Control:</label>
              <select
                value={exam.selectedTopic}
                onChange={(e) => setExam(prev => ({ ...prev, selectedTopic: e.target.value }))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs font-serif text-white focus:outline-none focus:ring-1 focus:ring-[#CCA352]"
                id="oral-topic-selector"
              >
                {TOPIC_SUGGESTIONS.map((t, idx) => (
                  <option key={idx} value={t}>{t}</option>
                ))}
              </select>
            </div>

            {/* Difficulty Mode (Básico, Solemne, Comisión) */}
            <div className="space-y-2">
              <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">Exigencia del Sínodo:</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: "basico", title: "🌱 Básico", desc: "Retroalimentación orientadora." },
                  { id: "solemne", title: "⚖ Solemne", desc: "Riguroso examen USS." },
                  { id: "comision", title: "💀 Comisión", desc: "Alta presión y repreguntas." }
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setExam(prev => ({ ...prev, difficulty: item.id as any }))}
                    className={`p-3 rounded-lg border text-left transition-all ${
                      exam.difficulty === item.id
                        ? "bg-[#CCA352]/10 border-[#CCA352] text-white shadow"
                        : "bg-slate-900/50 border-slate-850 text-slate-400 hover:border-slate-800"
                    }`}
                    id={`diff-btn-${item.id}`}
                  >
                    <span className="text-[11px] font-semibold block">{item.title}</span>
                    <span className="text-[9px] text-slate-400 mt-0.5 block leading-tight">{item.desc}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="border-t border-slate-850 pt-5 flex justify-center">
            <button
              onClick={startExam}
              disabled={loading}
              className="bg-gradient-to-r from-[#BCA374] to-[#CCA352] text-slate-950 font-mono text-xs uppercase font-extrabold tracking-widest px-8 py-3.5 rounded-lg flex items-center gap-2 transition-transform hover:scale-[1.02] shadow-md shadow-[#CCA352]/10 disabled:opacity-50"
              id="start-oral-exam-btn"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  Convocando Sínodo USS...
                </>
              ) : (
                <>
                  <Scroll className="w-4 h-4" />
                  Rendir Examen Oral USS
                </>
              )}
            </button>
          </div>
        </div>
      ) : (
        /* DURING EXAM FLOW */
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6" id="oral-live-exam-board">
          {/* Question / Response (Left 7 Columns) */}
          <div className="md:col-span-7 space-y-5">
            {!exam.isFinished ? (
              <div className="bg-[#11151D] border border-slate-800 rounded-xl p-5 space-y-4 shadow-xl">
                {/* Progress banner */}
                <div className="flex justify-between items-center text-[10px] font-mono border-b border-slate-850 pb-2 mb-2">
                  <span className="text-[#CCA352] flex items-center gap-1">
                    <Star className="w-3 h-3 text-[#CCA352] animate-pulse" />
                    PREGUNTA {exam.currentQuestionIndex} DE 5
                  </span>
                  <span className="text-slate-550 uppercase">
                    MODALIDAD: {exam.difficulty}
                  </span>
                </div>

                {/* Sylvan character speech */}
                {exam.currentQuestionIndex === 1 && exam.welcomeMessage && (
                  <div className="bg-amber-950/20 border border-amber-900/30 rounded-lg p-3 text-xs font-serif text-amber-200 italic leading-relaxed">
                    &ldquo;{exam.welcomeMessage}&rdquo;
                  </div>
                )}

                {/* Question bubble */}
                <div className="p-4 bg-slate-950 border border-[#CCA352]/20 rounded-lg space-y-2">
                  <span className="text-[10px] font-mono text-[#BCA374] uppercase block">Interrogación Oral Directa:</span>
                  <p className="text-xs font-serif text-white italic font-bold leading-relaxed">
                    &ldquo;{exam.currentQuestion}&rdquo;
                  </p>
                </div>

                {/* Response text input */}
                <div className="space-y-2">
                  <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">Esclaresca su argumentación jurídica:</label>
                  <textarea
                    value={studentAnswer}
                    onChange={(e) => setStudentAnswer(e.target.value)}
                    disabled={loading}
                    placeholder="Escriba su respuesta de nivel universitario... (Se recomienda ser preciso doctrinariamente, citar pactismo, leyes o autores pertinentes)"
                    className="bg-slate-950 border border-slate-850 text-xs font-serif text-white p-4 rounded-lg w-full h-36 focus:outline-none focus:ring-1 focus:ring-[#CCA352]"
                    id="student-answer-textarea"
                  />
                  <div className="text-[10px] text-slate-500 font-mono text-right">
                    Usa terminología técnica: retroversión, pactismo, organicismo, doctrina...
                  </div>
                </div>

                {/* Send action */}
                <div className="flex justify-end pt-1">
                  <button
                    onClick={submitAnswer}
                    disabled={loading}
                    className="bg-[#CCA352] text-slate-950 hover:brightness-105 rounded-lg px-5 py-2.5 font-mono text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all disabled:opacity-50"
                    id="submit-answer-btn"
                  >
                    {loading ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        Analizando respuesta...
                      </>
                    ) : (
                      <>
                        <Send className="w-3.5 h-3.5" />
                        Defender Oralmente
                      </>
                    )}
                  </button>
                </div>
              </div>
            ) : (
              /* RESULTS PANEL: IF FINISHED */
              <div className="bg-[#FAF8F5] text-slate-900 border-2 border-[#CCA352] rounded-xl p-6 space-y-6 shadow-2xl relative overflow-hidden" id="oral-finished-panel">
                {/* Vintage Watermark background */}
                <div className="absolute inset-0 opacity-[0.02] pointer-events-none bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-900 via-transparent to-transparent"></div>

                <div className="border-b-2 border-slate-350 pb-4 text-center space-y-1">
                  <span className="font-mono text-[10px] tracking-widest text-[#BCA374] font-extrabold uppercase">
                    Sínodo Examinador de Cátedra USS
                  </span>
                  <h3 className="text-xl font-serif font-bold text-slate-900">
                    ACTA EXAMEN DE HISTORIA DEL DERECHO
                  </h3>
                  <p className="text-xs text-slate-500 font-serif">
                    Simulación Académica Oficial • Licenciatura en Ciencias Jurídicas 2026
                  </p>
                </div>

                {/* Score badge & Status block */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center bg-white p-5 rounded-lg border border-slate-200">
                  <div className="text-center md:text-left space-y-1">
                    <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block">DICTAMEN FINAL COMISIÓN:</span>
                    <span className={`text-2xl font-serif font-black tracking-widest block ${exam.scoreAvg >= 4.0 ? "text-emerald-700" : "text-red-700"}`}>
                      {exam.scoreAvg >= 4.0 ? "🏅 APROBADO CON DISTINCIÓN" : "❌ REPROBADO"}
                    </span>
                    <span className="text-xs text-slate-500 font-sans block">
                      Examen elaborado bajo modalidad de alta exigencia <strong className="uppercase">{exam.difficulty}</strong>.
                    </span>
                  </div>

                  <div className="text-center rounded-lg bg-slate-50 border border-slate-200 p-4 relative overflow-hidden">
                    <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest block mb-0.5">NOTA FINAL PONDERADA:</span>
                    <span className={`text-5xl font-serif font-black ${exam.scoreAvg >= 4.0 ? "text-emerald-800" : "text-red-800"}`}>
                      {exam.scoreAvg.toFixed(1)}
                    </span>
                    <div className="text-[9px] font-mono text-slate-400 mt-1 uppercase">Escala Chilena (1.0 - 7.0)</div>
                  </div>
                </div>

                {/* Closing Speech by mentor */}
                <div className="space-y-2">
                  <h4 className="text-[10px] uppercase font-mono tracking-wider text-[#BCA374] font-extrabold flex items-center gap-1">
                    <Scroll className="w-3.5 h-3.5 text-amber-800" />
                    Discurso Final del Prof. {mentorName}:
                  </h4>
                  <p className="text-xs font-serif text-slate-700 leading-relaxed text-justify bg-amber-50 rounded-lg p-4 border-l-4 border-[#CCA352] italic">
                    &ldquo;{exam.finalSpeech}&rdquo;
                  </p>
                </div>

                {/* Strengths & Weaknesses */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Strong points */}
                  <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4">
                    <span className="text-[10px] font-mono uppercase text-emerald-800 block font-bold mb-1.5 flex items-center gap-1">
                      🛡 Fortalezas Demostradas:
                    </span>
                    <ul className="text-xs font-serif text-emerald-950 space-y-1 pr-1 pl-4 list-disc">
                      {exam.strongPoints.map((pt, i) => (
                        <li key={i}>{pt}</li>
                      ))}
                    </ul>
                  </div>

                  {/* Weak points */}
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <span className="text-[10px] font-mono uppercase text-red-800 block font-bold mb-1.5 flex items-center gap-1">
                      ⚠️ Temas por Reforzar:
                    </span>
                    <ul className="text-xs font-serif text-red-950 space-y-1 pr-1 pl-4 list-disc">
                      {exam.weakPoints.map((pt, i) => (
                        <li key={i}>{pt}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Reset button */}
                <div className="border-t border-slate-200 pt-5 flex justify-center">
                  <button
                    onClick={() => setExam({
                      currentQuestionIndex: 0,
                      examHistory: [],
                      currentQuestion: null,
                      welcomeMessage: null,
                      selectedTopic: "General / Todo el Ramo",
                      difficulty: "solemne",
                      isStarted: false,
                      isFinished: false,
                      scoreAvg: 1.0,
                      finalSpeech: null,
                      strongPoints: [],
                      weakPoints: []
                    })}
                    className="bg-slate-900 text-[#CCA352] hover:bg-slate-800 border border-slate-700 rounded-lg px-6 py-2.5 font-mono text-xs uppercase font-extrabold tracking-widest transition-colors"
                    id="restart-oral-btn"
                  >
                    Rendir Nueva Simulación Oral
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Sínodo Log / Exam History Sidebar (Right 5 columns) */}
          <div className="md:col-span-5 space-y-4">
            <div className="bg-[#11151D] border border-slate-800 rounded-xl p-4 space-y-4 shadow-xl">
              <h3 className="text-xs font-mono uppercase tracking-widest text-slate-400 border-b border-slate-850 pb-2 flex items-center gap-1.5">
                📜 Libro de Actas de Exposición
              </h3>

              <div className="space-y-3 max-h-[480px] overflow-y-auto pr-1" id="exam-steps-scroller">
                {exam.examHistory.map((item, index) => (
                  <div
                    key={index}
                    className="bg-[#151B27]/90 border border-slate-800 rounded-lg p-3.5 space-y-3 text-xs"
                    id={`exam-step-${index}`}
                  >
                    <div className="flex justify-between items-center bg-slate-950/40 p-1.5 rounded border border-slate-800/60">
                      <span className="font-mono text-[9px] uppercase tracking-wide text-slate-450 font-bold">Pregunta {index + 1}</span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono border ${scoreColor(item.score)}`}>
                        Nota: {item.score.toFixed(1)}
                      </span>
                    </div>

                    <div className="space-y-1 font-serif text-slate-400">
                      <strong className="text-[10px] text-slate-500 font-mono block uppercase">Régimen Consultor:</strong>
                      <p className="italic text-slate-300 leading-relaxed">&ldquo;{item.question}&rdquo;</p>
                    </div>

                    <div className="space-y-1 font-serif text-slate-400">
                      <strong className="text-[10px] text-slate-500 font-mono block uppercase">Respuesta Alumno:</strong>
                      <p className="text-slate-200 italic leading-relaxed line-clamp-2">&ldquo;{item.answer}&rdquo;</p>
                    </div>

                    <div className="bg-slate-950 border border-teal-950/20 p-2.5 rounded text-slate-300 font-serif leading-light space-y-1">
                      <strong className="text-[9px] text-[#BCA374] font-mono block uppercase">Vedicto del Prof.:</strong>
                      <p className="text-[11px] leading-relaxed italic text-slate-300">{item.feedback}</p>
                    </div>

                    {item.errorsDetected.length > 0 && (
                      <div className="bg-red-950/20 border border-red-900/30 p-2 rounded text-[10px] text-red-300 font-mono flex flex-col gap-1">
                        <span className="font-bold">⚠️ Radar de Errores USS Activado:</span>
                        {item.errorsDetected.map((err, i) => (
                          <span key={i} className="pl-2 border-l border-red-800">- {err}</span>
                        ))}
                      </div>
                    )}
                  </div>
                ))}

                {exam.examHistory.length === 0 && (
                  <div className="py-8 text-center text-slate-500 font-serif">
                    <Compass className="w-8 h-8 text-slate-700 mx-auto mb-2 animate-spin" />
                    El sínodo no ha registrado respuestas. Inicie el examen e introduzga su defensa.
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
