import React, { useState } from "react";
import { PenSquare, Check, RotateCcw, Volume2, ShieldAlert } from "lucide-react";
import { USS_FAMOUS_QUOTES } from "../data";

interface MentorBadgeProps {
  mentorName: string;
  setMentorName: (name: string) => void;
  activeRoom: string;
}

export default function MentorBadge({ mentorName, setMentorName, activeRoom }: MentorBadgeProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedValue, setEditedValue] = useState(mentorName);
  const [currentQuote, setCurrentQuote] = useState(USS_FAMOUS_QUOTES[0]);

  const handleSave = () => {
    if (editedValue.trim() !== "") {
      setMentorName(editedValue.trim());
    }
    setIsEditing(false);
  };

  const drawRandomQuote = () => {
    const filterQuotes = USS_FAMOUS_QUOTES.filter(q => q !== currentQuote);
    const randomIdx = Math.floor(Math.random() * filterQuotes.length);
    setCurrentQuote(filterQuotes[randomIdx]);
  };

  // Get active mood based on active room
  const getMood = () => {
    switch (activeRoom) {
      case "sala-oral":
        return {
          text: "Modo Comisión Oral: Rigor Extremo",
          color: "text-red-400 bg-red-950/40 border-red-800/40",
          icon: "🎓"
        };
      case "camara-solemnes":
        return {
          text: "Evaluador de Cátedra: Alta Precisión",
          color: "text-amber-400 bg-amber-950/40 border-amber-800/40",
          icon: "🕯"
        };
      case "radar-errores":
        return {
          text: "Mentor Formador: Análisis de Errores",
          color: "text-emerald-400 bg-emerald-950/40 border-emerald-800/40",
          icon: "🛡"
        };
      case "brujula-juridica":
        return {
          text: "Tutor Socrático: Comprensión Guiada",
          color: "text-cyan-400 bg-cyan-950/40 border-cyan-800/40",
          icon: "🧭"
        };
      default:
        return {
          text: "Sereno & Reflexivo",
          color: "text-purple-400 bg-purple-950/40 border-purple-800/40",
          icon: "📜"
        };
    }
  };

  const mood = getMood();

  return (
    <div className="bg-[#11151D] border border-[#CCA352]/20 rounded-xl p-5 shadow-xl relative overflow-hidden" id="mentor-badge-card">
      {/* Decorative Golden Corner Flourishes */}
      <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-[#CCA352]/30 rounded-tl"></div>
      <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-[#CCA352]/30 rounded-tr"></div>
      <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-[#CCA352]/30 rounded-bl"></div>
      <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-[#CCA352]/30 rounded-br"></div>

      {/* Styled Classic-Academic Silhouette/Portrait */}
      <div className="flex flex-col items-center text-center">
        <div className="relative w-28 h-28 mb-4 rounded-full p-1 bg-gradient-to-b from-[#CCA352] to-slate-800 shadow-md">
          <div className="w-full h-full rounded-full bg-[#1A1F2B] overflow-hidden flex items-center justify-center relative">
            {/* High-quality generated artwork of Roman Emperor as Academic Scholar/Mentor */}
            <img 
              src="/src/assets/images/marcus_aurelius_1779656672630.png" 
              alt="Marco Aurelio Portrait mentor" 
              className="w-full h-full object-cover select-none"
              referrerPolicy="no-referrer"
            />
            <div className="absolute bottom-0 bg-slate-900/80 text-[10px] uppercase font-mono py-0.5 px-2 text-[#CCA352]">
              EST. 2026
            </div>
          </div>
          {/* Active indicator bead */}
          <div className="absolute right-1 bottom-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-[#11151D] flex items-center justify-center shadow">
            <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse"></span>
          </div>
        </div>

        {/* Dynamic Name Editor Section (nombre editable) */}
        <div className="w-full mb-2">
          {isEditing ? (
            <div className="flex items-center justify-center gap-2">
              <input
                type="text"
                value={editedValue}
                onChange={(e) => setEditedValue(e.target.value)}
                maxLength={40}
                className="bg-slate-900 border border-[#CCA352] text-xs font-serif rounded px-2 py-1 text-white focus:outline-none focus:ring-1 focus:ring-[#CCA352] text-center w-full max-w-[180px]"
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleSave();
                }}
                autoFocus
                placeholder="Nombre del Mentor"
                id="mentor-name-input"
              />
              <button
                onClick={handleSave}
                className="p-1 text-emerald-400 hover:bg-emerald-950/60 rounded border border-emerald-900/30 transition-colors"
                title="Guardar nombre"
                id="save-mentor-name-btn"
              >
                <Check className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <div className="flex items-center justify-center gap-1.5 group cursor-pointer" onClick={() => setIsEditing(true)}>
              <h3 className="text-lg font-serif font-semibold text-[#CCA352] tracking-wide" id="mentor-display-name">
                {mentorName}
              </h3>
              <PenSquare className="w-3.5 h-3.5 text-slate-500 hover:text-[#CCA352] opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          )}
          <p className="text-[10px] font-mono uppercase tracking-widest text-slate-400 mt-0.5">
            Mentor de Historia del Derecho USS
          </p>
        </div>

        {/* Tone/Mood bar */}
        <div className={`mt-2 flex items-center gap-1.5 px-3 py-1 text-xs font-mono rounded-full border ${mood.color}`} id="mentor-current-mood">
          <span>{mood.icon}</span>
          <span>{mood.text}</span>
        </div>

        {/* Wisdom Box (Voz de Marco Aurelio) */}
        <div className="mt-5 w-full bg-slate-950/50 rounded-lg p-3 border border-slate-800/40 text-left relative group">
          <div className="text-[10px] font-mono uppercase text-[#BCA374] flex items-center justify-between mb-1">
            <span className="flex items-center gap-1">
              <Volume2 className="w-3 h-3 text-[#CCA352]" />
              Voz de {mentorName.split(" ")[0]}
            </span>
            <button
              onClick={drawRandomQuote}
              className="p-0.5 hover:text-[#CCA352] transition-colors"
              title="Escuchar otra cita"
              id="refresh-quote-btn"
            >
              <RotateCcw className="w-2.5 h-2.5" />
            </button>
          </div>
          <p className="text-xs text-slate-300 font-serif italic leading-relaxed">
            &ldquo;{currentQuote}&rdquo;
          </p>
        </div>
      </div>
    </div>
  );
}
