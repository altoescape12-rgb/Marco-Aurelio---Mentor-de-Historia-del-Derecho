import React, { useState } from "react";
import { BookOpen, Sparkles, Send, RefreshCw, GraduationCap, ChevronRight, HelpCircle } from "lucide-react";

interface AulaMagnaProps {
  mentorName: string;
}

export default function AulaMagna({ mentorName }: AulaMagnaProps) {
  const [topic, setTopic] = useState("");
  const [level, setLevel] = useState<"simple" | "intermedio" | "universitario">("intermedio");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const quickPickTopics = [
    "Cabildo Abierto de 1810",
    "El Pactismo de Francisco Suárez",
    "El Ensayo Moralista de 1823",
    "La Constitución de 1833 e Hiperpresidencialismo"
  ];

  const handleQuery = async (selectedTopic?: string) => {
    const activeTopic = selectedTopic || topic;
    if (!activeTopic.trim()) {
      setErrorMsg("Por favor escribe un tema o selecciona uno de los sugeridos.");
      return;
    }

    setLoading(true);
    setErrorMsg(null);
    setResult(null);

    try {
      const response = await fetch("/api/mentor/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: "aula-magna",
          topic: activeTopic,
          level,
          mentorName
        }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || `Error del servidor (código ${response.status})`);
      }

      const data = await response.json();
      setResult(data.text);
    } catch (err: any) {
      setErrorMsg(err.message || "No se pudo conectar con el Aula Magna. Revisa el estado de la API.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6" id="aula-magna-panel">
      {/* Intro Header */}
      <div className="bg-[#1A202C] border border-[#CCA352]/20 rounded-xl p-5 shadow-inner">
        <h2 className="text-xl font-serif font-semibold text-white flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-[#CCA352]" />
          📜 Aula Magna: Clases y Explicaciones Académicas
        </h2>
        <p className="text-xs text-slate-300 mt-2 leading-relaxed">
          Aquí {mentorName} desglosa instituciones romanas, indianas o chilenas con rigurosidad. Adapta tu explicación al nivel de asimilación deseado:
        </p>
      </div>

      {/* Control Board */}
      <div className="bg-[#11151D] border border-slate-800 rounded-xl p-5 space-y-4 shadow-xl">
        {/* Suggestion tags */}
        <div>
          <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-2">
            Temas Clave USS (Haz clic para consultar de inmediato):
          </label>
          <div className="flex flex-wrap gap-2">
            {quickPickTopics.map((t, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setTopic(t);
                  handleQuery(t);
                }}
                className="text-xs bg-slate-900 hover:bg-[#CCA352]/10 border border-[#CCA352]/20 hover:border-[#CCA352] text-slate-300 rounded-lg px-3 py-1.5 transition-all text-left font-serif"
                id={`quick-topic-${idx}`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Input area */}
        <div className="space-y-2">
          <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">
            Escribe un tema de estudio personalizado:
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="Ej: El patronato nacional, la abolición de mayorazgos, la constitución moralista de Juan Egaña..."
              className="bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-[#CCA352] w-full"
              id="aula-magna-topic-input"
            />
          </div>
        </div>

        {/* Level Selector */}
        <div className="pt-2">
          <label className="text-[10px] font-mono uppercase tracking-wider text-[#BCA374] block mb-2">
            Selecciona el Nivel de Profundidad Doctrinal:
          </label>
          <div className="grid grid-cols-3 gap-3">
            {[
              { id: "simple", label: "🌱 Simple", desc: "Analogías, lenguaje cotidiano, asimilación base." },
              { id: "intermedio", label: "⚖ Intermedio", desc: "Uso de conceptos formales y encuadre constitucional." },
              { id: "universitario", label: "🎓 Universitario", desc: "Debates de autores, doctrina dura e historiografía USS." }
            ].map((lvl) => (
              <button
                key={lvl.id}
                onClick={() => setLevel(lvl.id as any)}
                className={`p-3 rounded-lg border text-left transition-all flex flex-col justify-between ${
                  level === lvl.id
                    ? "bg-[#CCA352]/10 border-[#CCA352] text-white shadow-md shadow-[#CCA352]/5"
                    : "bg-slate-900/50 border-slate-800 text-slate-400 hover:border-slate-700"
                }`}
                id={`lvl-btn-${lvl.id}`}
              >
                <span className="text-xs font-semibold font-mono">{lvl.label}</span>
                <span className="text-[10px] text-slate-400 mt-1 block leading-snug">{lvl.desc}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex justify-end pt-3">
          <button
            onClick={() => handleQuery()}
            disabled={loading}
            className="bg-gradient-to-r from-[#BCA374] to-[#CCA352] text-slate-950 hover:brightness-110 font-mono text-xs uppercase font-bold tracking-wider px-5 py-3 rounded-lg flex items-center gap-2 transition-all shadow-md disabled:opacity-50"
            id="aula-magna-submit-btn"
          >
            {loading ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                Interrogando el archivo...
              </>
            ) : (
              <>
                <Send className="w-3.5 h-3.5" />
                Iniciar Lección
              </>
            )}
          </button>
        </div>
      </div>

      {/* Error Output */}
      {errorMsg && (
        <div className="bg-red-950/40 border border-red-950 p-4 rounded-xl text-red-200 text-xs flex gap-2 items-center" id="aula-magna-error">
          <span className="text-lg">⚠</span>
          <p>{errorMsg}</p>
        </div>
      )}

      {/* Results Deck */}
      {loading && (
        <div className="bg-[#11151D] border border-slate-800/40 rounded-xl p-8 text-center" id="aula-magna-loader">
          <RefreshCw className="w-8 h-8 text-[#CCA352] animate-spin mx-auto mb-3" />
          <p className="text-sm font-serif italic text-slate-400">
            &ldquo;El Derecho requiere paciencia y estudio. Permíteme ordenar pedagógicamente mis apuntes doctrinales...&rdquo;
          </p>
          <span className="text-[10px] font-mono text-slate-500 mt-1 block">Accediendo a la cátedra de Historia del Derecho USS</span>
        </div>
      )}

      {result && (
        <div className="bg-[#FAF8F5] text-slate-900 border border-[#CCA352]/20 rounded-xl p-6 shadow-xl relative overflow-hidden" id="parchment-results">
          {/* Visual Parchment Watermark Design */}
          <div className="absolute top-0 right-0 w-32 h-32 opacity-[0.03] select-none pointer-events-none mt-2 mr-2">
            <svg viewBox="0 0 100 100" className="w-full h-full text-slate-900">
              <path d="M10,10 L90,10 L90,90 L10,90 Z M20,20 L80,20 M20,30 L80,30 M20,40 L60,40" stroke="currentColor" strokeWidth="2" />
            </svg>
          </div>

          <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
            <div className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-widest text-[#BCA374]">
              <span className="font-bold text-amber-800">Cátedra USS</span>
              <span className="text-slate-400">|</span>
              <span className="text-slate-500">Nivel {level}</span>
            </div>
            <div className="text-xs font-serif italic text-slate-500">
              Prof. {mentorName}
            </div>
          </div>

          <div className="prose prose-sm max-w-none text-slate-800" id="aula-magna-lesson-content">
            {result.split("\n").map((line, idx) => {
              const trimmed = line.trim();
              if (!trimmed) return <div key={idx} className="h-2" />;

              // Format custom header tags or numbers
              if (trimmed.startsWith("1.") || trimmed.startsWith("2.") || trimmed.startsWith("3.") || trimmed.startsWith("4.")) {
                return (
                  <h4 key={idx} className="text-sm font-semibold font-serif text-slate-900 mt-4 mb-2 flex items-center gap-1">
                    <ChevronRight className="w-3.5 h-3.5 text-[#BCA374]" />
                    {trimmed}
                  </h4>
                );
              }
              if (trimmed.startsWith("PREGUNTA SOCRÁTICA") || trimmed.startsWith("Pregunta Socrática") || trimmed.startsWith("Pregunta socrática")) {
                return (
                  <div key={idx} className="my-5 p-4 bg-amber-50 border-l-4 border-amber-500 rounded-r-lg text-amber-900 text-xs shadow-sm font-serif">
                    <p className="font-bold font-mono tracking-wider text-[10px] uppercase text-amber-800 mb-1 flex items-center gap-1">
                      <HelpCircle className="w-3.5 h-3.5" />
                      INTERROGACIÓN SOCRÁTICA:
                    </p>
                    {trimmed}
                  </div>
                );
              }

              return <p key={idx} className="text-xs text-slate-700 leading-relaxed font-serif text-justify mb-2">{trimmed}</p>;
            })}
          </div>

          {/* Socratic callout encouragement */}
          <div className="mt-6 pt-4 border-t border-slate-200 text-[10px] text-slate-500 font-mono text-center">
            &ldquo;Intellige Historiam, Comprehende Ius&rdquo; • Universidad San Sebastián
          </div>
        </div>
      )}
    </div>
  );
}
