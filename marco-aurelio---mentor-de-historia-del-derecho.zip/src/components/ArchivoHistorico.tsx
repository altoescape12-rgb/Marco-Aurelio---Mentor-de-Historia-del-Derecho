import React, { useState } from "react";
import { Book, Search, Layers, Star, ExternalLink, Bookmark } from "lucide-react";
import { HISTORICAL_LIBRARY } from "../data";
import { LibraryItem } from "../types";

export default function ArchivoHistorico() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedBook, setSelectedBook] = useState<LibraryItem | null>(HISTORICAL_LIBRARY[0]);

  const filteredLibrary = HISTORICAL_LIBRARY.filter(book =>
    book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    book.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
    book.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
    book.keyConcepts.some(c => c.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="space-y-6" id="archivo-historico-panel">
      {/* Intro Header */}
      <div className="bg-[#121A21] border border-[#CCA352]/20 rounded-xl p-5 shadow-lg">
        <h2 className="text-xl font-serif font-semibold text-white flex items-center gap-2">
          <Book className="w-5 h-5 text-[#CCA352]" />
          🏛 Archivo Histórico: Fuentes Primarias y Doctrinales USS
        </h2>
        <p className="text-xs text-slate-300 mt-1 lines-relaxed">
          Consulta las obras magnas, códigos de derecho común e historiografías recomendadas en el cedulario oficial. Estudiar directamente de la doctrina previene la memorización mecánica de datos falsos.
        </p>
      </div>

      {/* Main Grid: List on left, details on right */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* List of Books */}
        <div className="md:col-span-5 bg-[#11151D] border border-slate-800 rounded-xl p-4 space-y-4 shadow-xl">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3.5" />
            <input
              type="text"
              placeholder="Buscar obra, autor o concepto..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-[#CCA352] w-full"
              id="search-books-input"
            />
          </div>

          <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1" id="books-scroller">
            {filteredLibrary.map((book, idx) => (
              <button
                key={idx}
                onClick={() => setSelectedBook(book)}
                className={`w-full text-left p-3 rounded-lg border transition-all ${
                  selectedBook?.title === book.title
                    ? "bg-[#CCA352]/10 border-[#CCA352] text-white shadow-sm"
                    : "bg-slate-900/50 border-slate-850 text-slate-400 hover:border-slate-800 hover:text-slate-200"
                }`}
                id={`book-item-btn-${idx}`}
              >
                <div className="flex items-start justify-between">
                  <span className="text-xs font-serif font-bold text-slate-200 group-hover:text-white line-clamp-1">
                    {book.title}
                  </span>
                  <Bookmark className={`w-3 h-3 flex-shrink-0 ${selectedBook?.title === book.title ? "text-[#CCA352] fill-[#CCA352]" : "text-slate-600"}`} />
                </div>
                <div className="flex justify-between items-center mt-1.5 font-mono text-[9px] text-[#BCA374]">
                  <span>{book.author.split(" (")[0]}</span>
                  <span>{book.period}</span>
                </div>
              </button>
            ))}

            {filteredLibrary.length === 0 && (
              <p className="text-xs text-slate-500 font-mono text-center py-4">No se encontraron manuales doctrinales bajo ese criterio.</p>
            )}
          </div>
        </div>

        {/* Detailed Book Card on Right */}
        <div className="md:col-span-7">
          {selectedBook ? (
            <div className="bg-[#11151D] border border-slate-800 rounded-xl p-6 space-y-5 shadow-xl relative overflow-hidden" id="book-detail-panel">
              <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
                <Book className="w-36 h-36 text-white" />
              </div>

              {/* Title & Badge */}
              <div className="space-y-1.5 border-b border-slate-800 pb-4">
                <div className="text-[10px] uppercase font-mono tracking-widest text-[#BCA374] flex items-center gap-1">
                  <Layers className="w-3 h-3 text-[#CCA352]" />
                  Doctrina Recomendada USS Cátedra
                </div>
                <h3 className="text-lg font-serif font-bold text-white leading-snug">
                  {selectedBook.title}
                </h3>
                <p className="text-xs text-slate-400 font-mono">
                  Autor: <span className="text-[#CCA352]">{selectedBook.author}</span> • Época: {selectedBook.period}
                </p>
              </div>

              {/* Importance Highlight */}
              <div className="bg-amber-950/20 border border-amber-900/30 rounded-lg p-3 text-amber-300 text-xs font-serif leading-relaxed flex items-start gap-2">
                <Star className="w-4 h-4 text-[#CCA352] fill-[#CCA352] flex-shrink-0 mt-0.5 animate-pulse" />
                <div>
                  <strong className="block font-sans text-[10px] uppercase font-bold tracking-wider text-amber-400 mb-0.5">Trascendencia en Historia del Derecho:</strong>
                  {selectedBook.importance}
                </div>
              </div>

              {/* Summary */}
              <div className="space-y-2">
                <h4 className="text-xs uppercase font-mono tracking-wider text-slate-400">Síntesis Analítica Doctrinal</h4>
                <p className="text-xs font-serif text-slate-300 leading-relaxed text-justify">
                  {selectedBook.summary}
                </p>
              </div>

              {/* Key Concepts Tags */}
              <div className="space-y-2 pt-2">
                <h4 className="text-xs uppercase font-mono tracking-wider text-slate-450">Términos Clave Relacionados:</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedBook.keyConcepts.map((concept, i) => (
                    <span
                      key={i}
                      className="text-[10px] font-mono text-[#CCA352] bg-slate-900/80 border border-slate-800 rounded px-2 py-1"
                    >
                      🏷 {concept}
                    </span>
                  ))}
                </div>
              </div>

              {/* Study action button */}
              <div className="border-t border-slate-800/80 pt-4 flex justify-between items-center">
                <span className="text-[10px] text-slate-500 font-mono">USS • Biblioteca de Historia Constitucional</span>
                <div className="text-[11px] text-slate-400 font-serif italic">
                  Lectura Obligatoria Cedulario 2026
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full flex items-center justify-center border border-dashed border-slate-800 rounded-xl p-8 text-slate-400 font-serif">
              Selecciona un manual del Archivo Doctrinario para desglosarlo.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
