import React, { useState } from "react";
import { Compass, BookOpen, FileText, ArrowRight, RefreshCw, Send, CheckCircle } from "lucide-react";

interface BrujulaJuridicaProps {
  mentorName: string;
}

export default function BrujulaJuridica({ mentorName }: BrujulaJuridicaProps) {
  const [activeSubTab, setActiveSubTab] = useState<"lectura" | "traduccion" | "iris">("lectura");
  const [inputText, setInputText] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Suggested paragraphs for "Lectura Guiada"
  const readingExamples = [
    {
      label: "Orden Portaliano (1833)",
      text: "La Constitución de 1833 consagró un régimen de 'autoritarismo legal'. El Presidente de la República gozaba de facultades extraordinarias para suspender las garantías individuales en caso de revuelta, convirtiéndose en el gran legislador y elector de la República, subordinando al Congreso a un plano secundario mediante el ejercicio del Patronato republicano."
    },
    {
      label: "El Pactismo de 1810",
      text: "Asumiendo que el Rey legítimo se hallaba privado de su libertad por la usurpación napoleónica, de suyo operaba la retroversión de la soberanía al pueblo. Este hecho conllevó no un cisma constituyente originario, sino una delegación transitoria fundada en la doctrina tradicional escolástica del pacto de sujeción."
    }
  ];

  // Common doctrinal translations pre-coded for interactive quick exploration
  const interactiveTranslations = [
    {
      techName: "Representación orgánica-corporativa",
      plainExplanation: "El pueblo no se gobierna ni se expresa mediante sufragio universal directo de individuos aislados (un ciudadano, un voto). En su lugar, el poder se ejerce y se representa a través de los cuerpos tradicionales jerarquizados preexistentes de la sociedad, como los Cabildos, familias, gremios e Iglesia.",
      example: "Al establecerse la Junta de 1810, no se llamó a una elección parlamentaria inmediata, sino que concurrieron los vecinos conspicuos del cabildo civil de manera corporativa."
    },
    {
      techName: "Retroversión de la Soberanía",
      plainExplanation: "Teoría jurídica que postula que la autoridad del monarca surge de un contrato original con el pueblo. Por ende, si el monarca falta, la soberanía moral e institucional regresa de forma innata al pueblo (sociedad civil) para que determine su autogobierno transitorio.",
      example: "Cuando Fernando VII de España es encarcelado, los cabildos americanos asumen el control provisional en su nombre."
    },
    {
      techName: "Patronato Nacional / Republicano",
      plainExplanation: "Derecho reclamado por los gobiernos independientes post-coloniales para controlar el nombramiento de obispos, la creación de diócesis y el cobro de diezmos, atribuciones que originalmente el Papa le había concedido exclusivamente a la Corona española.",
      example: "Durante todo el siglo XIX, Chile discutió con el Vaticano si este derecho era 'heredado' por el Estado chileno de forma inherente o si debía ser concedido de nuevo por el Papa."
    }
  ];

  const handleAnalizeReading = async () => {
    if (!inputText.trim()) {
      setErrorMsg("Por favor, ingresa o selecciona un texto para que analicemos.");
      return;
    }
    setLoading(true);
    setErrorMsg(null);
    setResult(null);

    try {
      const response = await fetch("/api/mentor/reading-analysis", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          textSnippet: inputText,
          mentorName
        })
      });

      if (!response.ok) {
        throw new Error(`Error en el servidor de análisis (código ${response.status})`);
      }

      const data = await response.json();
      setResult(data.text);
    } catch (err: any) {
      setErrorMsg(err.message || "Error al conectar con la Brújula de Lectura.");
    } finally {
      setLoading(false);
    }
  };

  const handleDoctrinalQuery = async (concept: string) => {
    setLoading(true);
    setErrorMsg(null);
    setResult(null);

    try {
      const response = await fetch("/api/mentor/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: "traduccion-doctrinal",
          topic: concept,
          mentorName
        })
      });

      if (!response.ok) throw new Error("Error en la traducción doctrinal del servidor.");
      const data = await response.json();
      setResult(data.text);
    } catch (err: any) {
      setErrorMsg(err.message || "Error de traducción.");
    } finally {
      setLoading(false);
    }
  };

  const handleIrisQuery = async (concept: string) => {
    setLoading(true);
    setErrorMsg(null);
    setResult(null);

    try {
      const response = await fetch("/api/mentor/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: "metodo-iris",
          topic: concept,
          mentorName
        })
      });

      if (!response.ok) throw new Error("Error en la ejecución IRIS.");
      const data = await response.json();
      setResult(data.text);
    } catch (err: any) {
      setErrorMsg(err.message || "Error al invocar IRIS.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6" id="brujula-juridica-panel">
      {/* Overview Block */}
      <div className="bg-[#0B1520] border border-[#CCA352]/20 rounded-xl p-5 shadow-lg">
        <div className="flex items-center gap-3">
          <Compass className="w-6 h-6 text-[#CCA352] animate-pulse" />
          <div>
            <h2 className="text-xl font-serif font-semibold text-white">
              Compass / Brújula Jurídica: Comprensión Lectora y Exégesis
            </h2>
            <p className="text-xs text-slate-400 font-mono mt-0.5">MÉTODO LEX & IRIS • UNIVERSIDAD SAN SEBASTIÁN</p>
          </div>
        </div>
        <p className="text-xs text-slate-300 mt-2 leading-relaxed">
          Un gran jurista no memoriza mecánicamente: domina las sutilezas lingüísticas de los textos doctrinales. Esta brújula pedagógica te permite traducir discursos arcaicos, desglosar extractos complejos y estructurar tus saberes con el riguroso método IRIS.
        </p>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex border-b border-slate-800" id="brujula-subtabs">
        <button
          onClick={() => { setActiveSubTab("lectura"); setResult(null); setErrorMsg(null); }}
          className={`flex-1 py-3 text-xs font-mono uppercase tracking-wider border-b-2 text-center transition-all ${
            activeSubTab === "lectura" ? "border-[#CCA352] text-white bg-slate-900/40" : "border-transparent text-slate-400 hover:text-slate-200"
          }`}
          id="tab-lectura-guided"
        >
          📖 A. Lectura Guiada
        </button>
        <button
          onClick={() => { setActiveSubTab("traduccion"); setResult(null); setErrorMsg(null); }}
          className={`flex-1 py-3 text-xs font-mono uppercase tracking-wider border-b-2 text-center transition-all ${
            activeSubTab === "traduccion" ? "border-[#CCA352] text-white bg-slate-900/40" : "border-transparent text-slate-400 hover:text-slate-200"
          }`}
          id="tab-traduccion-doc"
        >
          🗣 B. Traducción Doctrinal
        </button>
        <button
          onClick={() => { setActiveSubTab("iris"); setResult(null); setErrorMsg(null); }}
          className={`flex-1 py-3 text-xs font-mono uppercase tracking-wider border-b-2 text-center transition-all ${
            activeSubTab === "iris" ? "border-[#CCA352] text-white bg-slate-900/40" : "border-transparent text-slate-400 hover:text-slate-200"
          }`}
          id="tab-iris-method"
        >
          👁 C. Método IRIS
        </button>
      </div>

      {/* SUBTAB CONTENT 1: LECTURA GUIADA */}
      {activeSubTab === "lectura" && (
        <div className="space-y-4" id="guided-reading-flow">
          <div className="bg-[#11151D] border border-slate-800 rounded-xl p-5 space-y-4">
            <h3 className="text-sm font-serif font-semibold text-[#CCA352] flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Entrenamiento de Análisis de Textos de Estudio
            </h3>
            <p className="text-xs text-slate-300">
              Pega un párrafo de tus apuntes o lecturas complementarias de Álvaro Iriarte. {mentorName} lo leerá contigo, detectando ideas fuerzas y planteándote preguntas de asimilación estructural.
            </p>

            {/* Quick selectors */}
            <div className="space-y-1.5">
              <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500 block">Ejemplos para ensayar:</span>
              <div className="flex gap-2">
                {readingExamples.map((ex, i) => (
                  <button
                    key={i}
                    onClick={() => setInputText(ex.text)}
                    className="text-xs bg-slate-950 hover:bg-[#CCA352]/10 border border-slate-800 text-slate-300 px-3 py-2 rounded-lg transition-colors font-serif"
                    id={`reading-ex-btn-${i}`}
                  >
                    {ex.label}
                  </button>
                ))}
              </div>
            </div>

            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Pega un párrafo del manual o apunte doctrinal..."
              className="bg-slate-950 border border-slate-850 rounded-lg p-4 text-xs font-serif text-white h-36 w-full focus:outline-none focus:ring-1 focus:ring-[#CCA352]"
              id="reading-textarea"
            />

            <div className="flex justify-end">
              <button
                onClick={handleAnalizeReading}
                disabled={loading}
                className="bg-[#CCA352] text-slate-950 hover:brightness-105 px-4 py-2.5 rounded-lg text-xs font-mono font-bold tracking-wider uppercase flex items-center gap-1.5 transition-all disabled:opacity-50"
                id="analyse-reading-btn"
              >
                {loading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                Interpretar Texto Guiado
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB CONTENT 2: TRADUCCIÓN DOCTRINAL */}
      {activeSubTab === "traduccion" && (
        <div className="space-y-4" id="doctrinal-translation-flow">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {interactiveTranslations.map((item, idx) => (
              <div
                key={idx}
                className="bg-[#11151D] border border-slate-800 hover:border-[#CCA352]/40 rounded-xl p-4 transition-all flex flex-col justify-between"
                id={`translation-card-${idx}`}
              >
                <div>
                  <h4 className="text-xs font-bold text-[#CCA352] font-mono uppercase tracking-wide">
                    {item.techName}
                  </h4>
                  <p className="text-xs text-slate-300 mt-2 font-serif leading-relaxed h-28 overflow-y-auto">
                    <span className="text-slate-500 font-mono text-[10px] uppercase block mb-1">Traducción a lenguaje claro:</span>
                    {item.plainExplanation}
                  </p>
                  <p className="text-[11px] text-[#BCA374] italic mt-2 font-serif">
                    <strong>Caso concreto:</strong> {item.example}
                  </p>
                </div>

                <button
                  onClick={() => handleDoctrinalQuery(item.techName)}
                  disabled={loading}
                  className="mt-4 border border-[#CCA352]/20 hover:border-[#CCA352] text-[10px] font-mono text-[#CCA352] hover:bg-[#CCA352]/10 py-2 rounded-lg text-center transition-colors uppercase font-bold"
                  id={`translation-deep-btn-${idx}`}
                >
                  Indagar Doctrina USS
                </button>
              </div>
            ))}
          </div>

          <div className="bg-[#11151D] border border-slate-800 rounded-xl p-5 space-y-3">
            <h3 className="text-xs font-serif font-semibold text-white">¿Quieres traducir otro concepto abstracto?</h3>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Ej: Vacancia Fideicomisaria, Patronato Regio, Doctrinas Indianas..."
                className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white w-full focus:ring-1 focus:ring-[#CCA352] focus:outline-none"
                id="doc-concept-input"
              />
              <button
                onClick={(e) => {
                  const input = document.getElementById("doc-concept-input") as HTMLInputElement;
                  if (input && input.value.trim()) handleDoctrinalQuery(input.value.trim());
                }}
                disabled={loading}
                className="bg-gradient-to-r from-slate-900 to-slate-800 border border-slate-700 text-[#CCA352] px-4 rounded-lg text-xs font-mono font-bold"
                id="custom-translate-btn"
              >
                Traducir
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB CONTENT 3: MÉTODO IRIS */}
      {activeSubTab === "iris" && (
        <div className="space-y-4" id="iris-flow">
          <div className="bg-[#11151D] border border-slate-800 rounded-xl p-5 space-y-4">
            <h3 className="text-sm font-serif font-semibold text-[#CCA352] flex items-center gap-2">
              👁 El Método I.R.I.S. (Estructura de Pensamiento Jurídico USS)
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Consiste en estructurar tu análisis de cualquier hito legal/constitucional bajo 4 prismas dogmáticos para evitar memorización vacía:
            </p>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-center">
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                <span className="text-sm block">🗂</span>
                <span className="text-xs font-bold block font-mono text-[#CCA352] mt-1">I - Identificar</span>
                <span className="text-[10px] text-slate-400 mt-1 block">¿Qué es técnica y cronológicamente?</span>
              </div>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                <span className="text-sm block">🔗</span>
                <span className="text-xs font-bold block font-mono text-[#CCA352] mt-1">R - Relacionar</span>
                <span className="text-[10px] text-slate-400 mt-1 block">¿Con qué procesos del ramo se vincula?</span>
              </div>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                <span className="text-sm block">💡</span>
                <span className="text-xs font-bold block font-mono text-[#CCA352] mt-1">I - Interpretar</span>
                <span className="text-[10px] text-slate-400 mt-1 block">¿Cuál es la ratio jurídica profunda?</span>
              </div>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                <span className="text-sm block">📝</span>
                <span className="text-xs font-bold block font-mono text-[#CCA352] mt-1">S - Sintetizar</span>
                <span className="text-[10px] text-slate-400 mt-1 block">Reducción conceptual para rendir.</span>
              </div>
            </div>

            <div className="pt-2">
              <span className="text-xs text-slate-300 font-serif block mb-2">Selecciona un concepto para aplicarle el Método IRIS inmediatamente:</span>
              <div className="flex flex-wrap gap-2">
                {["Derecho Indiano", "Pactismo de Francisco Suárez", "Constitución de 1833", "Constitución de 1925", "Leyes Laicas", "Cabildos Abiertos"].map((concept, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleIrisQuery(concept)}
                    className="text-xs font-mono border border-slate-800 hover:border-[#CCA352] bg-slate-950 text-slate-300 px-3 py-1.5 rounded-lg transition-colors"
                    id={`iris-concept-${idx}`}
                  >
                    🔍 IRIS: {concept}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Action Loader */}
      {loading && (
        <div className="bg-[#11151D] border border-slate-800/40 rounded-xl p-8 text-center" id="brujula-loader">
          <RefreshCw className="w-8 h-8 text-[#CCA352] animate-spin mx-auto mb-3" />
          <p className="text-xs font-serif italic text-slate-400">
            &ldquo;Analizando con precisión exegética bajo las pautas del Dr. Álvaro Iriarte... Un momento, por favor.&rdquo;
          </p>
        </div>
      )}

      {errorMsg && (
        <div className="bg-red-950/40 border border-red-950 p-3 rounded-lg text-red-200 text-xs" id="brujula-error">
          ⚠ {errorMsg}
        </div>
      )}

      {/* Analisys Output Parchment */}
      {result && !loading && (
        <div className="bg-[#FAF8F5] text-slate-900 border border-[#CCA352]/20 rounded-xl p-6 shadow-xl font-serif text-justify" id="reading-parchment">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
            <span className="font-mono text-[10px] uppercase tracking-widest text-[#BCA374] font-bold">
              Diagnóstico de Exégesis • {activeSubTab === "lectura" ? "Comprensión Guiada" : activeSubTab === "iris" ? "Estructura IRIS" : "Traducción Doctrinal"}
            </span>
            <span className="text-xs italic text-slate-500">USS Historia del Derecho</span>
          </div>

          <div className="prose prose-sm max-w-none text-slate-800 space-y-4">
            {result.split("\n").map((line, idx) => {
              const trimmed = line.trim();
              if (!trimmed) return <div key={idx} className="h-1.5" />;

              // Main sections headers styling
              if (trimmed.startsWith("📖") || trimmed.startsWith("🔍") || trimmed.startsWith("🧭") || trimmed.startsWith("📊") || trimmed.startsWith("🔗") || trimmed.startsWith("💡") || trimmed.startsWith("📝") || trimmed.startsWith("1.") || trimmed.startsWith("2.") || trimmed.startsWith("3.") || trimmed.startsWith("4.")) {
                return (
                  <h4 key={idx} className="text-sm font-bold font-serif text-slate-900 mt-4 mb-2 border-b border-amber-200/50 pb-1 flex items-center gap-1.5">
                    {trimmed}
                  </h4>
                );
              }

              return <p key={idx} className="text-xs text-slate-700 leading-relaxed font-serif text-justify">{trimmed}</p>;
            })}
          </div>

          <div className="mt-6 pt-4 border-t border-slate-200 text-[10px] text-slate-500 font-mono text-center">
            &ldquo;Comprender antes de memorizar • Universidad San Sebastián&rdquo;
          </div>
        </div>
      )}
    </div>
  );
}
